/*
* igResizeBehavior.js
* Version 12.1.20121.2236
* Copyright(c) 2001-2013 Infragistics, Inc. All Rights Reserved.
*/


Type.registerNamespace('Infragistics.Web.UI');
$IG.ResizeBehavior = function(element)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ResizeBehavior">Class which implements resizing behavior.</summary>
	/// <param name="element" type="Object" mayBeNull="false">Reference to html element.</param>
	$IG.ResizeBehavior.initializeBase(this, [element]);




















	this._props = ['', '', '', 0, 0, 2000, 2000, 0, 0, 0, 0, 0, '', '', '', '', '', ''];
}
$IG.ResizeBehavior.prototype =
{
	/// <summary>Internal flag used by WebDialogWindow to temporary disable resize.</summary>
	enabled:true,
	
	get_pairs:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ResizeBehavior.pairs">Internal use only.</summary>
	},
	
	set_pairs:function(vals)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ResizeBehavior.pairs">Internal use only.</summary>
		vals = vals.split('|');
		for(var i = 0; i < vals.length; i += 2)
		{
			var id = parseInt(vals[i]), val = vals[i + 1];
			this._props[id] = (id > 2 && id < 12) ? parseInt(val) : $util.replace(val, '&pipe;', '|');
			if(id == 2)
				this._border = parseInt(val.substring(0, 1));
		}
	},
	
	get_handleClass:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ResizeBehavior.handleClass">Gets sets name of css class used for handle element as String.</summary>
		return this._get_(0);
	},
	set_handleClass:function(val)
	{
		this._set_(0, val);
		if(this._hand) this._hand.className = val;
	},
	
	get_handleImage:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ResizeBehavior.handleImage">Gets sets value of src used for IMG displayed on handle element as String.</summary>
		return this._get_(1);
	},
	set_handleImage:function(val)
	{
		this._set_(1, val);
		if(this._hand) this._hand.src = val;
	},
	get_resizeBorder:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ResizeBehavior.resizeBorder">Gets sets thickness of border around target element in pixels as Number. It can be null.</summary>
		return this._get_(2);
	},
	set_resizeBorder:function(val)
	{
		this._set_(2, val);
		this._border = $util.isEmpty(val) ? null : parseInt(val.substring(0, 1));
	},
	
	get_minimumWidth:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ResizeBehavior.minimumWidth">Gets sets minimum width of target in pixels as Number.</summary>
		return this._get_(3);
	},
	set_minimumWidth:function(val)
	{
		this._set_(3, val);
	},
	
	get_minimumHeight:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ResizeBehavior.minimumHeight">Gets sets minimum height of target in pixels as Number.</summary>
		return this._get_(4);
	},
	set_minimumHeight:function(val)
	{
		this._set_(4, val);
	},
	
	get_maximumWidth:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ResizeBehavior.maximumWidth">Gets sets maximum width of target in pixels as Number.</summary>
		return this._get_(5);
	},
	set_maximumWidth:function(val)
	{
		this._set_(5, val);
	},
	
	get_maximumHeight:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ResizeBehavior.maximumHeight">Gets sets maximum height of target in pixels as Number.</summary>
		return this._get_(6);
	},
	set_maximumHeight:function(val)
	{
		this._set_(6, val);
	},
	
	get_offsetLeft:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ResizeBehavior.offsetLeft">Gets offset of left edge of handle in pixels as Number.</summary>
		return this._get_(7);
	},
	set_offsetLeft:function(val)
	{
		this._set_(7, val);
	},
	
	get_offsetTop:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ResizeBehavior.offsetTop">Gets offset of top edge of handle in pixels as Number.</summary>
		return this._get_(8);
	},
	set_offsetTop:function(val)
	{
		this._set_(8, val);
	},
	
	get_offsetRight:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ResizeBehavior.offsetRight">Gets offset of right edge of handle in pixels as Number.</summary>
		return this._get_(9);
	},
	set_offsetRight:function(val)
	{
		this._set_(9, val);
	},
	
	get_offsetBottom:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ResizeBehavior.offsetBottom">Gets offset of bottom edge of handle in pixels as Number.</summary>
		return this._get_(10);
	},
	set_offsetBottom:function(val)
	{
		this._set_(10, val);
	},
	
	get_parentType:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ResizeBehavior.parentType">Gets sets type of resizing as Number. Possible values: 2 - internal, 0 - external.
		/// Note: set method is available only while initialization.
		/// </summary>
		return this._get_(11);
	},
	set_parentType:function(val)
	{
		this._set_(11, val);
	},
	
	get_toolTip:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ResizeBehavior.toolTip">Gets sets tooltip for handle element. The set method may have 2nd param as true: do not adjust server state.</summary>
		return this._get_(12);
	},
	set_toolTip:function(val, v)
	{
		if(!v) this._set_(12, val);
		v = this._hand;
		if(v) v.alt = v.title = val;
	},
	
	get_resize:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ResizeBehavior.resize">Gets sets name of function which is called after resize events.
		/// Note: set method is available only while initialization.
		/// </summary>
		return this._get_(13);
	},
	set_resize:function(val)
	{
		this._set_(13, val, 'Resize');
	},
	add_resize:function(handler)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ResizeBehavior.add_resize">Adds function which is called after resize events.</summary>
		/// <param name="handler">Function.</param>
		$util.addClientEvent(this, 'Resize', handler);
	},
	remove_resize:function(handler)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ResizeBehavior.remove_resize">Removes function which was called after resize events.</summary>
		/// <param name="handler">Function.</param>
		$util.removeClientEvent(this, 'Resize', handler);
	},
	
	get_resizing:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ResizeBehavior.resizing">Gets sets name of function which is called before resize events.
		/// Note: set method is available only while initialization.
		/// </summary>
		return this._get_(14);
	},
	set_resizing:function(val)
	{
		this._set_(14, val, 'Resizing');
	},
	add_resizing:function(handler)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ResizeBehavior.add_resizing">Adds function which is called before resize events.</summary>
		/// <param name="handler">Function.</param>
		$util.addClientEvent(this, 'Resizing', handler);
	},
	remove_resizing:function(handler)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ResizeBehavior.remove_resizing">Removes function which was called before resize events.</summary>
		/// <param name="handler">Function.</param>
		$util.removeClientEvent(this, 'Resizing', handler);
	},
	
	get_mouseover:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ResizeBehavior.mouseover">Gets sets name of function which is called on mouseover events.
		/// Note: set method is available only while initialization.
		/// </summary>
		return this._get_(15);
	},
	set_mouseover:function(val)
	{
		this._set_(15, val, 'MouseOver');
	},
	add_mouseover:function(handler)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ResizeBehavior.add_mouseover">Adds function which is called on mouseover events.</summary>
		/// <param name="handler">Function.</param>
		$util.addClientEvent(this, 'MouseOver', handler);
	},
	remove_mouseover:function(handler)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ResizeBehavior.remove_mouseover">Removes function which was called on mouseover events.</summary>
		/// <param name="handler">Function.</param>
		$util.removeClientEvent(this, 'MouseOver', handler);
	},
	
	get_mouseout:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ResizeBehavior.mouseout">Gets sets name of function which is called on mouseout events.
		/// Note: set method is available only while initialization.
		/// </summary>
		return this._get_(16);
	},
	set_mouseout:function(val)
	{
		this._set_(16, val, 'MouseOut');
	},
	add_mouseout:function(handler)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ResizeBehavior.add_mouseout">Adds function which is called on mouseout events.</summary>
		/// <param name="handler">Function.</param>
		$util.addClientEvent(this, 'MouseOut', handler);
	},
	remove_mouseout:function(handler)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ResizeBehavior.remove_mouseout">Removes function which was called on mouseout events.</summary>
		/// <param name="handler">Function.</param>
		$util.removeClientEvent(this, 'MouseOut', handler);
	},
	
	get_initialize:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ResizeBehavior.initialize">Gets sets name of function which is called after initialization.
		/// Note: set method is available only while initialization.
		/// </summary>
		return this._get_(17);
	},
	set_initialize:function(val)
	{
		this._set_(17, val, 'Initialize');
	},
	
	getFrameElement:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ResizeBehavior.getFrameElement">Gets reference to target-frame html element.</summary>
		/// <returns type="Object">Html element.</returns>
		return this._handDad;
	},
	getHandleElement:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ResizeBehavior.getHandleElement">Gets reference to handle html element.</summary>
		/// <returns type="Object">Html element.</returns>
		return this._hand;
	},
	initialize:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ResizeBehavior.initialize">Initializes instance of ResizeBehavior.</summary>
		$IG.ResizeBehavior.callBaseMethod(this, 'initialize');
		this._target = this.getTargetElement();
		if(!this._target)
		{
			throw 'Target element for ResizeBehavior not found';
			return;
		}
		if(this._onTimer(true))
			delete this._onTimer;
		else
		{
			ig_ui_timer(this);
			this._timerOn = 1;
		}
	},
	_shift: function()
	{
		this._s.marginLeft = (this._shiftX + this._divX - this._bdr) + 'px';
		this._s.marginTop = (this._shiftY + this._divY - this._bdr) + 'px';
	},
	_onTimer: function(init)
	{
		if(this._width)
			return true;
		var elem = this._target, ctl = this._control;
		var val = elem ? elem.offsetWidth : 0;
		if(!val || val == 0)
			return false;
		if(ctl && ctl.canResize && !ctl.canResize())
			return false;
		this._width = val;
		this._height = elem.offsetHeight;
		var tag = elem.nodeName;
		
		this._bdr = this._divX = this._divY = 0;
		val = this.get_parentType();
		
		this._div = (val == 2) || !(tag == 'DIV' || tag == 'SPAN');
		var td = (tag == 'TABLE' && val != 2) ? elem.rows[0] : null;
		if(td) td = td.cells[0];
		else if(val == 1) this._div = false;
		if(tag == 'TD') td = elem;
		
		var zi = 0, style = $util.getRuntimeStyle(elem);
		if(this._div && !td)
		{
			val = $util.getStyleValue(style, 'position');
			if(elem.type == 'hidden')
				alert('Can not attach resizer to a hidden element ' + elem.id);
		}
		if(val == 'absolute' || val == 'relative')
		{
			zi = $util.getStyleValue(style, 'zIndex');
			if(!zi || zi < 1) zi = 99999;
		}
		
		this._shiftX = $util.getOffset(style, true, true);
		this._shiftY = $util.getOffset(style, false, true);
		this._widthFix = this._shiftX + $util.getOffset(style, true, false, true);
		this._heightFix = this._shiftY + $util.getOffset(style, false, false, true);
		this._shiftHandX = $util.toIntPX(style, 'borderRightWidth');
		this._shiftHandY = $util.toIntPX(style, 'borderBottomWidth');
		
		val = this.get_offsetLeft();
		this._shiftX = -this._shiftX + val;
		this._shiftWidth = val - this.get_offsetRight();
		val = this.get_offsetTop();
		this._shiftY = -this._shiftY + val;
		this._shiftHeight = val - this.get_offsetBottom();
		val = this.get_stateValue();
		if(val)
		{
			val = val.split(',');
			if(!$util.isEmpty(val[0]))
				this._width = $util.toInt(val[0]);
			if(!$util.isEmpty(val[1]))
				this._height = $util.toInt(val[1]);
		}
		
		this._handDad = document.createElement('DIV');
		this._s = style = this._handDad.style;
		
		if(td)
			elem = td;
		if(!td && this._div)
		{
			td = elem;
			elem = elem.parentNode;
			if(zi > 0) style.zIndex = zi + 1;
		}
		else
			td = elem.firstChild;
		
		style.width = style.height = '0px';
		this._shift();
		style.position = 'absolute';
		elem.insertBefore(this._handDad, td);
		
		val = this.get_handleImage();
		if(val && val.length > 0)
		{
			this._im = elem = document.createElement('IMG');
			elem.src = val;
			elem._me = this;
			$addHandlers(elem, {'readystatechange':this._resize, 'load':this._resize}, this);
		}
		else
			elem = document.createElement('DIV');
		elem.className = this.get_handleClass();
		elem.style.position = 'absolute';
		elem.unselectable = 'on';
		
		this._hand = elem;
		this.set_toolTip(this.get_toolTip(), true);
		this._handDad.appendChild(elem);
		val = $util.getStyleValue(null, 'cursor', elem);
		if(!val || val == 'auto')
			elem.style.cursor = val = 'SE-resize';
		this._s.cursor = val;
		$addHandlers(this._hand, {'mousedown':this._onMouseDown, 'mouseover':this._onMouseOver, 'mouseout':this._onMouseOut,
			'touchstart':this._onTStart, 'touchmove':this._onTMove, 'touchend':this._onTEnd,
			'MSPointerDown':this._onMSStart, 'MSPointerMove':this._onMSMove, 'MSPointerUp':this._onMSEnd}, this);
		this._hand.style.msTouchAction = 'none';
		this._onMouseMoveFn = Function.createDelegate(this, this._onMouseMove);
		this._onMouseUpFn = Function.createDelegate(this, this._onMouseUp);
		this._onSelectFn = Function.createDelegate(this, this._onSelectStart);
		this._resize();
		if(!ctl)
			this._raiseClientEvent('Initialize');
		return true;
	},
	_resize: function(e)
	{
		var im = this._im, hand = this._hand, elem = this._target;
		if(!hand)
			return;
		if(im && (im.complete || im.readyState == 'complete'))
			e = this._im = null;
		var width = this._width, height = this._height;
		if(e)
		{
			var b = e.button;
			if(b == 0 && e.rawEvent)
				b = e.rawEvent.button;
			if(b == 1)
				this._but = 1;
			if(this._but == 1 && this._drag && b != 1)
			{
				this._onMouseUp(e);
				return;
			}
			if(!e.type || e.type.indexOf('m') != 0)
				return;
			var x = e.clientX, y = e.clientY;
			if(this._x == null)
			{
				this._x = x;
				this._y = y;
				this._widthOld = width;
				this._heightOld = height;
			}
			x -= this._x;
			y -= this._y;
			if(x == 0 && y == 0)
				return;
			width = this._widthOld + x;
			height = this._heightOld + y;
			
			var args = this._raiseClientEvent('Resizing', 'Resize', e, null, width, height, this._widthOld, this._heightOld);
			if(args && args.get_cancel())
				return;
		}
		else if(this._im)
			return;
		var handWidth = hand.offsetWidth, handHeight = hand.offsetHeight;
		width = Math.min(Math.max(width, Math.max(this.get_minimumWidth(), handWidth) + this._widthFix), this.get_maximumWidth());
		height = Math.min(Math.max(height, Math.max(this.get_minimumHeight(), handHeight) + this._heightFix), this.get_maximumHeight());
		var style = elem.style;
		var width0 = width - this._widthFix, height0 = height - this._heightFix;
		if(this.enabled)
		{
			style.width = width0 + 'px';
			style.height = height0 + 'px';
			width0 = elem.offsetWidth;
			height0 = elem.offsetHeight;
			if(width0 > width)
			{
				width = width0;
				style.width = (width - this._widthFix) + 'px';
			}
			if(height0 > height)
			{
				height = height0;
				style.height = (height - this._heightFix) + 'px';
			}
			
			if(this._control && this._control.onResize)
				this._control.onResize(e);
		}
		this._width = width;
		this._height = height;
		
		if(this._div)
		{
			var p0 = $util.getPosition(elem), p1 = $util.getPosition(this._handDad);
			this._divY -= (p1.y - p0.y + this._bdr - this.get_offsetTop());
			this._divX -= (p1.x - p0.x + this._bdr - this.get_offsetLeft());
			if(!this._drag)
				this._shift();
		}
		if(this._drag)
			this._onMouseOver(e, true);
		hand.style.left = (elem.offsetWidth - handWidth - this._shiftWidth - this._shiftHandX) + 'px';
		hand.style.top = (elem.offsetHeight - handHeight - this._shiftHeight - this._shiftHandY) + 'px';
	},
	_onTStart:function(e)
	{
		$util.cancelEvent(e);
		this._x = null;
		this._touch = true;
	},
	_onTMove:function(e)
	{
		if(!this._touch)
			return;
		$util.cancelEvent(e);
		e = e.rawEvent;
		var t = e.touches[0];
		this._drag = true;
		if(t)
			this._resize({clientX:t.pageX, clientY:t.pageY, button:0, type:'mousemove', rawEvent: e});
	},
	_onTEnd:function(e)
	{
		if(!this._touch)
			return;
		$util.cancelEvent(e);
		this._onMouseUp(e);
		delete this._touch;
	},
	_onMSStart:function(e)
	{
		var re = e.rawEvent;
		if(re.pointerType != 2)
			return;
		$util.cancelEvent(e);
		var src = this._MSsrc = e.target;
		src.msSetPointerCapture(this._MSpointer = re.pointerId);
		this._MSupHandler = this._MSupHandler || Function.createDelegate(this, this._onMSEnd);
		if (!this._MSupOn)
			$addHandler(document, 'MSPointerUp', this._MSupHandler);
		this._MSupOn = true;
		// fake events expected on mousedown to prepare for drag
		this._x = null;
		this._touch = true;
	},
	_onMSMove:function(e)
	{
		if(!this._MSpointer)
			return;
		$util.cancelEvent(e);
		// fake events expected on mousemove while drag
		e = e.rawEvent;
		this._drag = true;
		this._resize({clientX:e.pageX, clientY:e.pageY, button:0, type:'mousemove', rawEvent: e});
	},
	_onMSEnd:function(e)
	{
		var p = this._MSpointer, src = this._MSsrc, re = e.rawEvent;
		if (this._MSupOn)
			$removeHandler(document, 'MSPointerUp', this._MSupHandler);
		delete this._MSupOn;
		delete this._MSpointer;
		delete this._MSsrc;
		if(!p)
			return;
		src.msReleasePointerCapture(p);
		$util.cancelEvent(e);
		// fake events expected on mouseup after drag
		this._onMouseUp(e);
		delete this._touch;
	},
	setSize:function(width, height)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ResizeBehavior.setSize">Sets new size for target.</summary>
		/// <param name="width" type="Number">Width of target in pixels.</param>
		/// <param name="height" type="Number">Height of target in pixels.</param>
		this._width = width;
		this._height = height;
		this._resize();
		this.set_stateValue(this._width + ',' + this._height, true);
	},
	dispose: function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.ResizeBehavior.dispose">Disposes object and its event handlers.</summary>
		
		if (this._timerOn)
			ig_ui_timer(this, true);
		if(this._hand)
			$clearHandlers(this._hand);
		this._onMouseUp();
		$IG.ResizeBehavior.callBaseMethod(this, 'dispose');
	},
	_onMouseOver: function(e, noEvt)
	{
		if(this._touch)
			return;
		if(e && noEvt !== true)
			this._mouseIn = true;
		if(this._drag && noEvt !== true)
			return;
		var elem = this._handDad;
		var width = this._target.offsetWidth - this._shiftWidth, height = this._target.offsetHeight - this._shiftHeight;
		this._s.width = ((width > 0) ? width : 0) + 'px';
		this._s.height = ((height > 0) ? height : 0) + 'px';
		if(this._drag && this._div)
		{
			this._shift();
			return;
		}
		if(noEvt === true)
			return;
		
		this._raiseClientEvent(this._prefix + 'MouseOver', null, e);
		if(!this._border)
			return;
		this._s.border = this.get_resizeBorder();
		this._bdr = this._border;
		this._shift();
	},
	_onMouseOut: function(e, noEvt)
	{
		if(this._touch)
			return;
		if(e && noEvt !== true)
			this._mouseIn = false;
		if(this._drag)
			return;
		
		this._raiseClientEvent(this._prefix + 'MouseOut', null, e);
		this._s.border = this._s.width = this._s.height = '0px';
		this._bdr = 0;
		if(!this._border)
			return;
		this._shift();
	},
	_onMouseDown: function(e)
	{
		if(this._touch)
			return;
	    if(e.button == 0)
	    {
		    this._x = null;
		    if(!e)if((e = window.event) == null)
			    return;
		    this._drag = true;
		    $util.cancelEvent(e);
		    $addHandler(document, 'mousemove', this._onMouseMoveFn);
		    $addHandler(document, 'mouseup', this._onMouseUpFn);
		    if(Sys.Browser.agent === Sys.Browser.Safari)
			    document.onselectstart = this._onSelectFn;
		    else
			    $addHandler(document, 'selectstart', this._onSelectFn);
		    this._showIframe(true);		
		}
	},
	
	_showIframe:function()
	{
		var ctl = this._control;
		if(ctl && ctl._get_resizeAreaElem)
			$util._setMouseBlock(ctl._get_resizeAreaElem());
	},
	
	_onMouseMove: function(e)
	{
		if(this._touch)
			return;
		if(this._drag)
		{
			this._resize(e ? e : window.event);
			this._showIframe(true);
		}
	},
	
	
	_onMouseUp: function(e)
	{
		if(!this._touch)
			$util._setMouseBlock();
		this._x = null;
		if(!this._drag)
			return;
		var same = this._widthOld == null || this._heightOld == null || (this._widthOld == this._width && this._heightOld == this._height);
		this.__dragResized = false; 
		var v, fix = null;
		
		var args = same ? null : this._raiseClientEvent('Resized', 'Resize', e, null, this._width, this._height, this._widthOld, this._heightOld);
		if(args)
		{
			if(args.get_cancel())
			{
				fix = this._width = this._widthOld;
				this._height = this._heightOld;
			}
			else
			{
				if((v = args._width) != null)
					fix = this._width = v;
				if((v = args._height) != null)
					fix = this._height = v;
			}
		}
		this._drag = false;
		if(!same)
		{
			if(fix != null || this._div)
				this._resize();
			
			else if(this._control && this._control.onResize)
				this._control.onResize();
			this.set_stateValue(this._width + ',' + this._height, true);
		}
		if(this._touch)
			return;
		$removeHandler(document, 'mousemove', this._onMouseMoveFn);
		$removeHandler(document, 'mouseup', this._onMouseUpFn);
		if(Sys.Browser.agent === Sys.Browser.Safari)
			document.onselectstart = null;
		else
			$removeHandler(document, 'selectstart', this._onSelectFn);
		if(!this._mouseIn)
			this._onMouseOut(e, true);		
	},
	_onSelectStart: function(e)
	{
		return this._drag ? $util.cancelEvent(e) : true;
	}
}
$IG.ResizeBehavior.registerClass('Infragistics.Web.UI.ResizeBehavior', $IG.Behavior);


$IG.ResizeEventArgs = function()
{
	/// <summary locid="T:J#Infragistics.Web.UI.ResizeEventArgs">Class used as param in resize events.</summary>
	$IG.ResizeEventArgs.initializeBase(this);
}
$IG.ResizeEventArgs.prototype =
{
	
	get_width:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ResizeEventArgs.width">Gets sets new width in pixels as Number.</summary>
		return this._props[2];
	},
	get_height:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ResizeEventArgs.height">Gets sets new height in pixels as Number.</summary>
		return this._props[3];
	},
	get_oldWidth:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ResizeEventArgs.oldWidth">Gets old width in pixels as Number.</summary>
		return this._props[4];
	},
	get_oldHeight:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.ResizeEventArgs.oldHeight">Gets old height in pixels as Number.</summary>
		return this._props[5];
	},
	set_width:function(val)
	{
		this._props[2] = this._width = val;
	},
	set_height:function(val)
	{
		this._props[3] = this._height = val;
	}
}
$IG.ResizeEventArgs.registerClass('Infragistics.Web.UI.ResizeEventArgs', $IG.CancelEventArgs);
