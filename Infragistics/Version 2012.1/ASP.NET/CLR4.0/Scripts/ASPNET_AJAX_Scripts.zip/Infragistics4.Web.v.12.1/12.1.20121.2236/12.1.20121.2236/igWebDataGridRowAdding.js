/*
* igWebDataGridRowAdding.js
* Version 12.1.20121.2236
* Copyright(c) 2001-2013 Infragistics, Inc. All Rights Reserved.
*/



$IG.RowAdding = function(obj, objProps, control, parentCollection)
{
	/// <summary locid="T:J#Infragistics.Web.UI.RowAdding">
	/// RowAdding behavior object of the grid.
	/// </summary>
	$IG.RowAdding.initializeBase(this, [obj, objProps, control, parentCollection]);
	this._addNewRowSelectorImgCssClass = this._get_clientOnlyValue("anrsc");

	
	

	this._rows = this._owner.get_rows();

	this._row = new $IG.AddNewGridRow(-1, control._elements["addNewRow"], [], this._grid, null);
	this._rowElement = this._row._element;
	this._row._container = this._row._element.parentNode.parentNode.parentNode;

	this._gridElementSelectStartHandler = Function.createDelegate(this, this._onSelectstartHandler);
	this._grid._gridUtil._registerEventListener(this._grid, "SelectStartContainer", this._gridElementSelectStartHandler);

	
	if ($util.IsOpera)
	{
		this._gridElementKeyPressHandler = Function.createDelegate(this, this._onKeypressHandler);
		this._grid._addElementEventHandler(this._grid._element, "keypress", this._gridElementKeyPressHandler);
	}
}

$IG.RowAdding.prototype =
{
	

	get_alignment: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowAdding.alignment">
		/// Returns the current Alignment of the add new row.
		/// </summary>
		/// <value type="Infragistics.Web.UI.AddNewRowAlignment"></value>
		return this._get_value($IG.RowAddingProps.Alignment);
	},



	get_row: function ()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowAdding.row">
		/// Returns a reference to the add new row.
		/// </summary>
		/// <value type="Infragistics.Web.UI.AddNewGridRow"></value>
		return this._row;
	},

	

	
	dispose: function ()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowAdding.dispose">
		/// This method is called by the framework, when the grid unloads.  This
		/// is where the RowAdding behavior removes all the event handlers that it
		/// had attached.
		/// </summary>

		if (!this._grid)
			return;

		if (this._addNewRowLostFocus)
		{
			this._grid._removeElementEventHandler(window.document.body, "mousedown", this._addNewRowLostFocus);
			delete this._addNewRowLostFocus;
		}
		if (this._checkImgHandlers)
		{
			for (var x = 0; x < this._checkImgHandlers.length; ++x)
			{
				this._grid._removeElementEventHandler(this._checkImgHandlers[x], "mousedown", this._addRowCheckboxMouseDownHandler);
				delete this._checkImgHandlers[x];
			}
			delete this._checkImgHandlers;
			delete this._addRowCheckboxMouseDownHandler;
		}
		if (this._addRowCheckboxKeyDownHandler)
		{
			this._grid._removeElementEventHandler(this._lastCheckboxCell, "keydown", this._addRowCheckboxKeyDownHandler);
			delete this._lastCheckboxCell;
			delete this._addRowCheckboxKeyDownHandler;
		}
		this._row.dispose();

		$IG.RowAdding.callBaseMethod(this, "dispose");

	},

	clearAddNewRow: function (resetDefaults)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.RowAdding.clearTextFromCells">
		/// This method will clear the add row and reset default values from column settings if 
		/// resetDefaults is true.
		/// </summary>
		/// <param name="resetDefaults" type="Boolean">Whether to restore default values of cells</param>

		for (var i = 0; i < this._row.get_cellCount(); i++)
		{
			var cell = this._row.get_cell(i);
			var column = cell.get_column();
			if (column._isCheck)
			{
				cell.get_element().setAttribute("val", "null");
				cell._setCheckState(2);
			}
			else
			{
				cell.set_text("");
				cell.get_element().removeAttribute("val");
			}
		}
		if (resetDefaults)
			this._initDefaultValues();

	},
	

	

	_onaddNewRowLostFocus: function (evnt)
	{
		var targetElement = evnt.srcElement;
		var currentElement = targetElement
		var parentElemMkr = null;


		var obj = $util.resolveMarkedElement(currentElement, true);
		var srcElemIsAddNewRow = false;


		if (obj && obj[2])
		{
			if (this._grid._uniqueID == obj[2]._uniqueID)
			{
				//See if we're on the add new row or not.
				while (currentElement != null && currentElement.mkr != "addNewRow")
					currentElement = currentElement.parentNode;

				if (currentElement == null)
				{
					if (targetElement.tagName == "INPUT")
					{
						if (this._activation)
						{
							var activeCell = this._activation.get_activeCell();
							if (activeCell != null)
								srcElemIsAddNewRow = (activeCell.get_row() == this._row) ? true : false;
						}
					}
				}
				else if (currentElement.mkr == "addNewRow")
					srcElemIsAddNewRow = true;
				else
					srcElemIsAddNewRow = false;

			}
			else
			{
				//We're on another control Commit the row and return.
				srcElemIsAddNewRow = false;
			}
		}
		else
		{
			//We're not on an aikido control, safe to say we're not on the add new row.
			srcElemIsAddNewRow = false;
		}

		if (this._grid._get_auxRowIndex(this._row, null) != -1)
			return;

		if (!srcElemIsAddNewRow && this._row._isDirty())
		{
			this._commitRow();
		}

	},

	_keyExitedEditMode: function (evntArgs)
	{
		var key = evntArgs.Evnt.keyCode;
		var cell = evntArgs.Cell;

		//If the row isn't dirty, just return.
		if (!this._row._isDirty())
			return;

		//If the enter key is pressed commit the row.
		if (key == Sys.UI.Key.enter)
		{
			this._operaCancelKeyPress = true;
			this._commitRow();
			$util.cancelEvent(evntArgs.Evnt);
		}

		//If the tab key is pressed, and we're about to tab off of the row, commit the row.
		if (key == Sys.UI.Key.tab && !evntArgs.Evnt.shiftKey)
		{
			//add row to grid's rows collection the client, updating should take care
			//of the rest.
			

			var colVisibleIndex = cell.get_column().get_visibleIndex();
			var lastVisibleIndex = this._grid._gridUtil._findLastVisibleColumn().get_visibleIndex();
			var allReadOnly = true;
			for (var i = colVisibleIndex + 1; i <= lastVisibleIndex; i++)
			{
				var currentCol = this._grid._gridUtil._getColumnFromVisibleIndex(i);
				var currentColSetting = this.get_columnSettings()._getObjectByAdr(currentCol.get_key());
				if (!currentColSetting || (currentColSetting && !currentColSetting.get_readOnly()))
				{
					allReadOnly = false;
					break;
				}
			}

			if (colVisibleIndex == lastVisibleIndex || allReadOnly)
				this._commitRow();
		}
		//If the esc key is pushed we should clear the row.
		else if (key == Sys.UI.Key.esc)
		{
			
			this.clearAddNewRow(true);
		}

	},

	_onKeypressHandler: function (evnt)
	{
		// Opera doesn't respect canceling the event in KeyDown, so we have to also cancel the event in KeyPress.
		if (this._operaCancelKeyPress)
			$util.cancelEvent(evnt);
		this._operaCancelKeyPress = false;
	},

	_onSelectstartHandler: function (evnt)
	{
		
		var currentElement = evnt.target;
		//See if we're on the add new row or not.
		while (currentElement != null && currentElement.mkr != "addNewRow")
			currentElement = currentElement.parentNode;

		if (currentElement != null && currentElement.mkr == "addNewRow")
			$util.cancelEvent(evnt);
	},
	

	

	_clearAddNewRow: function ()
	{
		for (var i = 0; i < this._row.get_cellCount(); i++)
		{
			var cell = this._row.get_cell(i);
			var col = cell._column;
			if (col._isCheck)
			{
				cell.get_element().setAttribute("val", "null");
				cell._setCheckState(2);
			}
			else
			{
				cell.set_text("");
				cell.get_element().removeAttribute("val");
			}
		}
	},

	_commitRow: function ()
	{
		var rowValues = new Array();

		for (var i = 0; i < this._row.get_cellCount(); i++)
		{
			var cell = this._row.get_cell(i);
			
			rowValues[i] = { 'Value': cell.get_value(), 'DataKeyField': this._grid.get_columns().get_column(i)._key };
			
			if (this._editing._batchUpdating && !this._row.get_cell(i)._column._isCheck)
			{
				rowValues[i].Text = cell.get_text();
				
				rowValues[i].IsNull = rowValues[i].Text === "" && cell.get_element().getAttribute("val") === null;
			}
		}

		this._rows.add(rowValues);
	},

	_enteringEditMode: function (eventArgs)
	{
		if (eventArgs.cell.get_row() === this._row)
		{
			if (this._grid._get_isAjaxCallInProgress())
			{
				eventArgs.customDisplay.cancel = true;
				return;
			}
			var extraLeft = 0;
			var extraTop = 0;
			if ((this._grid._hasHeaderLayout || this._grid._hasMultiColumnFooters) && eventArgs.cell._element.parentNode.getAttribute("mkr") == "addNewRowRight")
			{
				var cellElem = eventArgs.cell._element.parentNode;
				while (cellElem && cellElem.getAttribute("mkr") != "fxdCapThRight" && cellElem.parentNode)
					cellElem = cellElem.parentNode;
				if (cellElem && cellElem.getAttribute("mkr") == "fxdCapThRight")
				{
					extraLeft = cellElem.offsetLeft;
					extraTop = cellElem.offsetTop;
				}
			}
			else if ((this._grid._hasHeaderLayout || this._grid._hasMultiColumnFooters) && eventArgs.cell._element.parentNode.getAttribute("mkr") == "addNewRowLeft")
			{
				var cellElem = eventArgs.cell._element.parentNode;
				while (cellElem && cellElem.getAttribute("mkr") != "fxdCapThLeft" && cellElem.parentNode)
					cellElem = cellElem.parentNode;
				if (cellElem && cellElem.getAttribute("mkr") == "fxdCapThLeft")
				{
					extraTop = cellElem.offsetTop;
					
					if (this._rowSelectors && ((this._grid._hasHeaderLayout && this.get_alignment() == $IG.AddNewRowAlignment.Top) || (this._grid._hasMultiColumnFooters && this.get_alignment() == $IG.AddNewRowAlignment.Bottom)))
						extraLeft += cellElem.offsetLeft;
				}
			}
			else
				return;


			eventArgs.customDisplay.left = eventArgs.cell._element.offsetLeft + extraLeft;
			eventArgs.customDisplay.top = eventArgs.cell._element.offsetTop + extraTop;

		}
	},
	

	

	_initializeComplete: function ()
	{
		this._container = this._row._element;

		$IG.RowAdding.callBaseMethod(this, "_initializeComplete");

		this._addNewRowLostFocus = Function.createDelegate(this, this._onaddNewRowLostFocus);
		this._grid._addElementEventHandler(window.document.body, "mousedown", this._addNewRowLostFocus);

		//Get a reference to the editing interface.
		this._editing = this._grid.get_behaviors().getBehaviorFromInterface($IG.IEditingBehavior);

		this._addExitKeyHandledEventListener(Function.createDelegate(this, this._keyExitedEditMode));

		if (this._grid._hasHeaderLayout && this._grid.get_behaviors().get_columnFixing())
			this._addEnteringEditEventListener(Function.createDelegate(this, this._enteringEditMode));

		this._rowSelectors = this._grid.get_behaviors().getBehaviorFromInterface($IG.IRowSelectorsBehavior);
		if (this._rowSelectors)
			this._rowSelectors.addSelectorImage(this.get_row(), this._addNewRowSelectorImgCssClass);

		this._grid._registerAuxRow(this.get_row(), (this.get_alignment() == $IG.AddNewRowAlignment.Top ? $IG.GridAuxRows.Top : $IG.GridAuxRows.Bottom));

		this._initDefaultValues(true);
	},
	_initDefaultValues: function (init)
	{
		var cols = this._grid.get_columns();
		var colCount = cols.get_length();
		var row = this.get_row();
		if (init)
			this._checkImgHandlers = [];
		
		var lastVisCol = this._grid._gridUtil._findLastVisibleColumn();
		var lastVisibleIndex = lastVisCol ? lastVisCol.get_visibleIndex() : -1;
		for (var x = colCount - 1; x >= 0; --x)
		{
			var col = cols.get_column(x);
			var colSet = this.get_columnSettingFromKey(col.get_key());
			if (colSet != null)
			{
				var defaultVal = Sys.Serialization.JavaScriptSerializer.deserialize(colSet.get_defaultValue());
				
				var chkState = colSet._get_clientOnlyValue("radc");
				var text = colSet._get_clientOnlyValue("radt");
				if (defaultVal != null || chkState || text)
				{
					if (row.get_cell(x).get_column().get_type() == "date")
					{
						defaultVal = this._grid._gridUtil._convertServerDateStringToClientObject(defaultVal);
					}

					
					var cell = row.get_cell(x);
					cell._element.setAttribute("val", "null");
					if (chkState)
					{
						chkState = parseInt(colSet._get_clientOnlyValue("radc"));
						cell._set_value_internal(defaultVal, chkState);
					}
					else if (text)
						cell._set_value_internal(defaultVal, text);
					else
						cell._set_value_internal(defaultVal);
				}
			}
			if (init && col._isCheck && (!colSet || !colSet.get_readOnly()))
			{
				var imgCheck;
				var children = row.get_cell(x).get_element().childNodes;
				var childCount = children.length;
				for (var i = 0; i < childCount; ++i)
				{
					var child = children[i];
					$util._initAttr(child);
					if (child.getAttribute && child.getAttribute("chkState"))
					{
						imgCheck = child;
						break;
					}
				}
				if (imgCheck)
				{
					if (!this._addRowCheckboxMouseDownHandler)
						this._addRowCheckboxMouseDownHandler = Function.createDelegate(this, this._addRowCheckboxMouseDown);
					if (!this._addRowCheckboxKeyDownHandler && col.get_visibleIndex() == lastVisibleIndex)
					{
						this._addRowCheckboxKeyDownHandler = Function.createDelegate(this, this._addRowCheckboxKeyDown);
						this._lastCheckboxCell = row.get_cell(x).get_element();
						this._grid._addElementEventHandler(this._lastCheckboxCell, "keydown", this._addRowCheckboxKeyDownHandler);
					}
					this._checkImgHandlers[this._checkImgHandlers.length] = imgCheck;
					this._grid._addElementEventHandler(imgCheck, "mousedown", this._addRowCheckboxMouseDownHandler);
				}
			}
		}
	},
	_addRowCheckboxMouseDown: function (evnt)
	{
		var target = evnt.target;
		if (target.tagName != "IMG")
			return;
		var cell = target.parentNode ? this._owner._gridUtil.getCellFromElem(target.parentNode) : null;
		if (cell)
		{
			var checkbox = cell._get_ImgCheckbox();
			if (checkbox)
			{
				var checked = parseInt(checkbox.getAttribute("chkState"));
				var newValue = checked != $IG.CheckBoxState.Unchecked ? cell._column._defaultFalse : cell._column._defaultTrue;
				var newCheckedValue = checked != $IG.CheckBoxState.Unchecked ? 0 : 1;
				cell.set_value(newValue, newCheckedValue);
			}
		}
	},

	_addRowCheckboxKeyDown: function (evnt)
	{
		var target = evnt.target;
		var key = evnt.keyCode;
		var cell = this._owner._gridUtil.getCellFromElem(target);
		if (cell && key == Sys.UI.Key.enter)
		{
			this._commitRow();
			
			this._operaCancelKeyPress = true;
			$util.cancelEvent(evnt);
		}
	},

	_createCollections: function (collectionsManager)
	{
		this._columnSettings = collectionsManager.register_collection(0, $IG.ObjectCollection);
		var collectionItems = collectionsManager._collections[0];
		for (var columnKey in collectionItems)
			this._columnSettings._addObject($IG.RowAddingSetting, null, columnKey);

	},

	

	_get_editContainer: function ()
	{
		return this._row._element;
	}
}
$IG.RowAdding.registerClass('Infragistics.Web.UI.RowAdding', $IG.GridEditBase, $IG.IRowAddingBehavior);


$IG.AddNewRowAlignment = function () 
{
/// <summary locid="T:J#Infragistics.Web.UI.AddNewRowAlignment">
/// The enumeration defines where the add new row is displayed.
/// </summary>
/// <field name="Top" type="Number" integer="true" static="true">
/// Add new row is displayed in the header.
/// </field>
/// <field name="Bottom" type="Number" integer="true" static="true">
/// Add new row is displayed in the footer.
/// </field>
}
$IG.AddNewRowAlignment.prototype = 
{
   Top:0, 
   Bottom:1
};
$IG.AddNewRowAlignment.registerEnum("Infragistics.Web.UI.AddNewRowAlignment");



$IG.RowAddingProps = new function()
{
    this.Alignment        =  [$IG.GridBehaviorProps.Count + 0, $IG.AddNewRowAlignment.Bottom];
    this.Count             =  $IG.GridBehaviorProps.Count + 1;
};

 



$IG.AddNewGridRow = function(adr, element, props, owner, csm)
{	
	///<summary locid="T:J#Infragistics.Web.UI.AddNewGridRow">
	///Override of the GridRow object. Adds functionality for the add new row off the grid.
	///</summary>
	$IG.AddNewGridRow.initializeBase(this, [adr, element, props, owner, csm]);
}

$IG.AddNewGridRow.prototype = 
{
    _create_item:function(adr, index)
    {
        
		var cell = $IG.AddNewGridRow.callBaseMethod(this, '_create_item', [adr, index]);
		cell.__set_overrideCellUpdate(true);
		return cell;
    },
    
    _isDirty:function()
    {
        for(var i = 0; i<this.get_cellCount(); i++)
        {        
            if(this.get_cell(i).get_text() != "")
            {
                return true;
            }
        }
        return false;
    }
}

$IG.AddNewGridRow.registerClass('Infragistics.Web.UI.AddNewGridRow', $IG.GridRow);


$IG.RowAddingSetting = function (adr, element, props, owner, csm)
{
	/// <summary locid="T:J#Infragistics.Web.UI.ColumnEditableSetting">
	/// Object that defines a column editable setting for a grid behavior.
	/// </summary>
	$IG.RowAddingSetting.initializeBase(this, [adr, element, props, owner, csm]);
	
	this._defaultValue = this._get_clientOnlyValue("radv");
}

$IG.RowAddingSetting.prototype =
{
	get_defaultValue: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowAddingSetting.defaultValue">
		/// Gets the default value of the column's add row cell.
		/// </summary>
		/// <value type="String"></value>
		return this._defaultValue;
	},

	dispose: function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.RowAddingSetting.dispose">
		/// Disposes of the object.
		/// </summary>
		$IG.ColumnEditableSetting.callBaseMethod(this, "dispose");
		delete this._defaultValue;
	}
}
$IG.RowAddingSetting.registerClass('Infragistics.Web.UI.RowAddingSetting', $IG.ColumnEditableSetting);


