/*
* igLayoutPane.js
* Version 12.1.20121.2236
* Copyright(c) 2001-2013 Infragistics, Inc. All Rights Reserved.
*/



Type.registerNamespace('Infragistics.Web.UI');


$IG.LayoutPaneProps = new function()
{
    var count = $IG.ControlObjectProps.Count;
    this.ScrollLeft = [count++, 0];
    this.ScrollTop = [count++, 0];
    this.ScrollBars = [count++, 1];
    this.Count = count; 
};



$IG.ContentPaneProps = new function()
{
    var count = $IG.LayoutPaneProps.Count;
    this.ContentUrl = [count++, ''];
    this.Count = count;
};


$IG.LayoutPane = function(adr, elem, props, ctl, csm, col, par)
{
	/// <summary locid="T:J#Infragistics.Web.UI.LayoutPane">Base class used for items of WebSplitter, WebTab and WebDialogWindow.</summary>
	/// <param name="adr" type="String">Address. Internal use only.</param>
	/// <param name="elem" domElement="true">Html element. Internal use only.</param>
	/// <param name="props" type="Array">Properties. Internal use only.</param>
	/// <param name="ctl">Reference to control. Internal use only.</param>
	/// <param name="csm">Client state manager. Internal use only.</param>
	/// <param name="col">Reference to collection. Internal use only.</param>
	/// <param name="par">Reference to parent. Internal use only.</param>
	if(!csm)
		csm = new $IG.ObjectClientStateManager(props[0]);
	$IG.LayoutPane.initializeBase(this, [adr, elem, props, ctl, csm, col, par]);
}

$IG.LayoutPane.prototype =
{
	get_scrollLeft:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.LayoutPane.scrollLeft">Gets sets scroll left of pane's content as Number.</summary>
		/// <value type="Number" integer="true">Scroll position in pixels.</value>
		return this._get_value($IG.LayoutPaneProps.ScrollLeft);
	},
	set_scrollLeft:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.LayoutPane.scrollLeft">Sets scroll left of pane's content.</summary>
		/// <param name="val" type="Number" integer="true">Scroll position in pixels</param>
		if (this._get_value($IG.LayoutPaneProps.ScrollLeft) != val)
			this._set_value($IG.LayoutPaneProps.ScrollLeft, val);
		this.getBody().scrollLeft = val;
	},
	
	get_scrollTop:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.LayoutPane.scrollTop">Gets sets scroll top of pane's content as Number.</summary>
		/// <value type="Number" integer="true">Scroll position in pixels.</value>
		return this._get_value($IG.LayoutPaneProps.ScrollTop);
	},
	set_scrollTop:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.LayoutPane.scrollTop">Sets scroll top of pane's content.</summary>
		/// <param name="val" type="Number" integer="true">Scroll position in pixels</param>
		if (this._get_value($IG.LayoutPaneProps.ScrollTop) != val)
			this._set_value($IG.LayoutPaneProps.ScrollTop, val);
		this.getBody().scrollTop = val;
	},
	
	get_scrollBars:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.LayoutPane.scrollBars">Gets sets overflow for pane's content as Number. Value should match with server's ContentOverflow enum.</summary>
		/// <value type="Number" integer="true">Possible values: 0- visible, 1- auto, 2- scroll, 3- hidden.</value>
		return this._get_value($IG.LayoutPaneProps.ScrollBars);
	},
	set_scrollBars:function(val)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.LayoutPane.scrollBars">Sets overflow for pane's content.</summary>
		/// <param name="val" type="Number" integer="true">Possible values: 0- visible, 1- auto, 2- scroll, 3- hidden</param>
		this._set_value($IG.LayoutPaneProps.ScrollBars, val);
		if(val == 3) val = 'hidden';
		else if(val == 2) val = 'scroll';
		else if(val == 1) val = 'auto';
		else val = '';
		this.getBody().style.overflow = val;
	},
	
	get_contentUrl:function()
	{
		/// <summary locid="P:J#Infragistics.Web.UI.LayoutPane.contentUrl">Gets sets name of url used for pane's iframe. Note: set method has effect only if value for ContentUrl was set on server.</summary>
		/// <value type="String">Name of url</value>
		return this._get_value($IG.ContentPaneProps.ContentUrl);
	},
	set_contentUrl:function(val, noSrc)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.LayoutPane.contentUrl">Sets name of url used for pane's iframe.</summary>
		/// <param name="val" type="String">Name of url</param>
		/// <param name="noSrc" type="Boolean" optional="true" mayBeNull="true">True: do not set src attribute of IFRAME</param>
		this._set_value($IG.ContentPaneProps.ContentUrl, val);
		var frame = this.get_iframe(val);
		if(frame && !noSrc)
			frame.src = val;
	},
	
	findChild:function(id)
	{
		/// <summary locid="M:J#Infragistics.Web.UI.LayoutPane.findChild">Gets reference to child element from its id. That method also will attempt to search for a child within iframe, if ContentUrl is set or if iframe is first child in pane.</summary>
		/// <param name="id" type="String">The id of html element to find. In case of template, that can be a partial value with which the id of child ends up.</param>
		/// <returns domElement="true" mayBeNull="true">Reference to html element.</returns>
		var elem = $util.findChild(this.getBody(), id);
		if(!elem) if(elem = this.get_iframe()) try
		{
			elem = elem.contentWindow.document.getElementById(id);
		}
		catch(id){}
		return elem;
	},

	get_iframe:function(create)
	{
		/// <summary locid="P:J#Infragistics.Web.UI.LayoutPane.iframe">
		/// Gets reference to iframe element located in pane or null. It should be first child in pane.
		/// Method may include optional param. If it is true and IFRAME does not exist, then it is created dynamically.
		/// </summary>
		/// <returns domElement="true" mayBeNull="true">Reference to html element.</returns>
		var div = this.getBody();
		var nodes = div ? div.childNodes : null;
		if (!nodes)
			return null;
		var len = nodes.length;
		var elem = (len > 0) ? nodes[0] : null;
		if(elem && elem.nodeName == '#text')
			elem = nodes[1];
		if (elem && elem.nodeName != 'IFRAME')
			elem = null;
		if (!elem && create)
		{
			while (len-- > 0)
				div.removeChild(nodes[len]);
			elem = document.createElement('IFRAME');
			elem.marginHeight = elem.marginWidth = elem.frameBorder = '0';
			elem.style.width = elem.style.height = '100%';
			div.appendChild(elem);
		}
		return elem;
	},

	getClientWidth:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.LayoutPane.getClientWidth">That function is designed for internal usage only (part of LayoutManager).</summary>
		/// <returns type="Number" integer="true">Client width.</returns>
		if(this._width) return this._width;
		var elem = this.getBody();
		var width = elem.offsetWidth - $util.getOffset($util.getRuntimeStyle(elem), true);
		return (width > 0) ? width : 0;
	},

	getClientHeight:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.LayoutPane.getClientHeight">That function is designed for internal usage only (part of LayoutManager).</summary>
		/// <returns type="Number" integer="true">Client height.</returns>
		if(this._height) return this._height;
		var elem = this.getBody();
		var height = elem.offsetHeight - $util.getOffset($util.getRuntimeStyle(elem));
		return (height > 0) ? height : 0;
	},

	getBody:function()
	{
		/// <summary locid="M:J#Infragistics.Web.UI.LayoutPane.getBody">That function is designed for internal usage only (part of LayoutManager).</summary>
		/// <returns domElement="true">Container of child elements.</returns>
		return this._DIV ? this._DIV : this._element;
	},
	
	_onInit:function()
	{
		var x = this.get_scrollLeft(), y = this.get_scrollTop(), div = this.getBody();
		if(x > 0)
			div.scrollLeft = x;
		if(y > 0)
			div.scrollTop = y;
	},
	
	_onSubmit:function()
	{
		this._set_value($IG.LayoutPaneProps.ScrollLeft, this.getBody().scrollLeft);
		this._set_value($IG.LayoutPaneProps.ScrollTop, this.getBody().scrollTop);
	}
}

$IG.LayoutPane.registerClass('Infragistics.Web.UI.LayoutPane', $IG.UIObject);
