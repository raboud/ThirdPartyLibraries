/*
* igDropDown.js
* Version 12.1.20121.2236
* Copyright(c) 2001-2013 Infragistics, Inc. All Rights Reserved.
*/


Type.registerNamespace("Infragistics.Web.UI");
var $IG = Infragistics.Web.UI; 

$IG.DropDownPopupPosition = function () { 

	///<summary locid="T:J#Infragistics.Web.UI.DropDownPopupPosition">
	/// Enumeration for different dropdown container positions relative to the source element
	///</summary>
	///<field name="Default" type="Number" integer="true" static="true"> Bottom Left. This is also the AUTO mode, which means that the container will be automatically positioned wherever there is visible space </field>
	///<field name="Center" type="Number" integer="true" static="true"> (dropdown bottom center) - the source element will be centered above the dropdown container  </field>
	///<field name="Left" type="Number" integer="true" static="true"> the dropdown container will be positioned on the left of the source (not directly below it). They will be aligned in the same way on the y axis </field>
	///<field name="Right" type="Number" integer="true" static="true"> the dropdown container will be positioned on the right of the source (not directly below it). They will be aligned in the same way on the y axis</field>
	///<field name="TopLeft" type="Number" integer="true" static="true"> the dropdown container will be on top of the source, aligned on the left </field>
	///<field name="TopRight" type="Number" integer="true" static="true"> the dropdown container will be on top of the source, aligned on the right </field>
	///<field name="BottomLeft" type="Number" integer="true" static="true"> the dropdown container will be on the bottom of the source, aligned on the left</field>
	///<field name="BottomRight" type="Number" integer="true" static="true"> same as above, but alighed on the right </field>
}

$IG.DropDownPopupPosition.prototype = 
{
   Default:0, // Bottom Left. This is also the AUTO mode, which means that the container will be automatically positioned wherever there is visible space 
   Center:1, // (dropdown bottom center) - the source element will be centered above the dropdown container 
   Left:2, // the dropdown container will be positioned on the left of the source (not directly below it). They will be aligned in the same way on the y axis
   Right:3, // the dropdown container will be positioned on the right of the source (not directly below it). They will be aligned in the same way on the y axis
   TopLeft:4, // the dropdown container will be on top of the source, aligned on the left
   TopRight:5, // the dropdown container will be on top of the source, aligned on the right
   BottomLeft:6, // the dropdown container will be on the bottom of the source, aligned on the left
   BottomRight:7 // same as above, but alighed on the right
};

$IG.DropDownPopupPosition.registerEnum("Infragistics.Web.UI.DropDownPopupPosition");



$IG.DropDownBehavior = function(sourceElement, dropDownIsChild, outerContainer, noEvts, noMove) {

    ///<summary locid="T:J#Infragistics.Web.UI.DropDownBehavior">
    /// An object that allows the developer to specify elements and/or UIObjects that 
    /// should be source elements and/or target elements.  the Target element wll be the 
    /// drop down target (popup) while the source will be the element that receives 
    /// drop down events and which will cause the popup to show/hide
    ///</summary>

    // initializations
    if (!sourceElement) {
        throw Error.argumentNull('sourceElement');
    }

    this._sourceElement = sourceElement; // the source of the dropdown (it will receive the events and cause the dropdown to appear / dissappear)
    this._targetContainer = null; // dropdown container
    this._targetContent = null; //reference to the content in the target container - currently it is not used anywhere
    this._position = $IG.DropDownPopupPosition.Default; // $IG.DropDownPopupPosition (default is Bottom + Left + AUTO)

    this._outerContainer = outerContainer;
	this._extraOuterContainers = [];
    this._movingTargetAllowance = 0;
    
    this._offsetX = 0; // number of pixels by which the dropdown container will be offset from the source on the X axis
    this._offsetY = 0; // number of pixels by which the dropdown container will be offset from the source on the Y axis
    this._containerHeight = 0; // used to store the height of the dropdown container.
    this._offScreen = false; // if true, it means that IF and WHEN the dropdown is shown, it will be off the screen, therefore IF the positioning is AUTO, the position will be automatically adjusted

    // by default this is true, and in that case we will adjust the dropdown position if it is off screen (controllable by the user)
    this._enableAutomaticPositioning = true;
	
    this._enableMovingTargetWithSource = !noMove;
	
    this._noMove = noMove;

    this._enableAnimations = true; // by default animations are enabled
    this._animationType = $IG.AnimationEquationType.EaseInOut; // see $IG.AnimationEquationType in igAnimation.js

    this._visible = false; // whether the popup container is currently visible or not ; by default the popup container is initially closed

    this._visibleOnFocus = false; // if true, the dropdown will appear when the source gains focus
    this._visibleOnBlur = false; // if true, the dropdown will disappear when the source loses focus
    this._visibleOnMouseOver = false; // if true, the dropdown will appear once the mouse is over the source
    this._visibleOnClick = false; // if true, the dropdown will appear once the source is clicked - it's probably better to be mouseDOWN instead !
    this._visibleOnKeyDown = false; // if true, the dropdown will appear once the keyDown event is invoked on the source

    this._dropDownAnimation = null; // a reference to the drop down animation object, which extends $IG.AnimationBase
    this._animationDurationMs = 300; // default 300 ms - number of milliseconds  during which the animation will be performed

    this._zIndex = 10000;
    





    this._animationsContainer = null;
    // we need to store the targetcontainer bounds and initially set its height to zero , when animations are enabled
    // otherwise there will be a flickering because its height will be originally set to the default (max) one
    this._targetBounds = null;

    // whether the drop down panel is a child of the target or not (by default it is not, and can be anywhere
    // on the page, we use absolute positioning in order to position it exactly where it should be. If it is set to be a child
    // then we set the targetContainer to be the first child of the source (see the init() function)
    this._dropDownIsChild = dropDownIsChild;

    // a reference to the object that manages drop down events: see $IG.DropDownEvents
    this._events = new $IG.DropDownEvents(this);

    this._animationEndListener = null;

	
	if (!noEvts)
	{
		 // hook delegates
		 // mouse up on the source
		 this._mouseUpDelegate = Function.createDelegate(this, this._mouseUpHandler);
		 // mouse click on the source
		 this._mouseClickDelegate = Function.createDelegate(this, this._mouseClickHandler);
		 // mouse over on the source
		 this._mouseOverDelegate = Function.createDelegate(this, this._mouseOverHandler);
		 // mouse down on the source
		 this._mouseDownDelegate = Function.createDelegate(this, this._mouseDownHandler);
		 // key down on the source               
		 this._keyDownDelegate = Function.createDelegate(this, this._keyDownHandler);
		 // key up on the source
		 this._keyUpDelegate = Function.createDelegate(this, this._keyUpHandler);
		 // focus on the source
		 this._focusDelegate = Function.createDelegate(this, this._focusHandler);
		 // focus on the source
		 this._blurDelegate = Function.createDelegate(this, this._blurHandler);

		 // this is a special delegate which controls the iframe for the IE6.0 SELECT bug - so that it's always properly aligned behind the dropdown container
		 this._moveDelegate = Function.createDelegate(this, this._onMove);
	}
    // set interval to check periodically if the source's position is changed
    // if it is changed, we close the dropdown
    if (this._enableMovingTargetWithSource) {
    
        this._checkDelegate = Function.createDelegate(this, this._onCheckPosition);
        this._sourceLocation = $util.getLocation(this._sourceElement);
        this._sourceBounds = Sys.UI.DomElement.getBounds(this._sourceElement);
        this._closeCheckID = setInterval(this._checkDelegate, 500);
    }

}

$IG.DropDownBehavior.prototype =
{

	
	get_sourceElement: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.sourceElement">
		/// Returns the dropdown source elemenet (DOM Element)
		///</summary>
		///<returns domElement="true" mayBeNull="false">
		/// reference to the dropdown source element 
		///</returns>
		return this._sourceElement;
	},

	get_targetContainer: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.targetContainer">
		/// returns the dropdown container (DOM Element)
		///</summary>
		///<returns domElement="true" mayBeNull="false">
		/// reference to the dropdown target container 
		///</returns>
		return this._targetContainer;
	},

	get_animationsContainer: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.animationsContainer">
		/// returns the animations container (DOM Element)
		///</summary>
		///<returns domElement="true" mayBeNull="false">
		/// reference to the dropdown animations container - another element (div) that wraps the original target container
		///</returns>
		return this._animationsContainer;
	},

	set_targetContainer: function(container)
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.targetContainer">
		/// sets the target container for the dropdown behavior. This is the element that will be Dropped down
		///</summary>
		///<param name="container" type="Sys.UI.DomElement" domElement="true"></param>
		///<remarks>
		///
		///</remarks>
		if (!container)
		{
			throw Error.argumentNull('container');
		}
		this._targetContainer = container;
	},

	set_targetContainerHeight: function(height)
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.targetContainerHeight">
		/// the height of the target container in pixels
		///</summary>
		///<param name="height" type="Number" integer="true"> </param>
		this._targetBounds.height = height; // was this._targetBounds = height; ????? 
		this._containerHeight = height;

		if (this.get_enableAnimations())
			$util.setAbsoluteHeight(this._animationsContainer, height);
	},

	get_targetContent: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.targetContent">
		/// the target content is the first child of the targetContainer 
		///</summary>
		///<remarks>
		/// the target content is the first child of the targetContainer 
		///</remarks>
		///<returns domElement="true">
		/// reference to the target content (first child of the targetContainer)
		///</returns>
		return this._targetContent;
	},

	set_targetContent: function(content)
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.targetContent">
		/// element that will be the content of the target container, that's usually going to be its first child
		///</summary>
		///<param name="content" type="Sys.UI.DomElement" domElement="true"></param>
		///<remarks>
		///
		///</remarks>
		this._targetContent = content;
	},

	get_zIndex: function()
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.zIndex">
	/// z-index of the dropdown container 
	///</summary>
	///<value type="Number" integer="true"> integer indicating the z-index of the dropdown container </value>
		return this._zIndex;

	},

	set_zIndex: function(zindex)
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.zIndex">
		/// sets a custom z-index on the target container element
		/// the idea of this is to be used when the container doesn't show when other elements "behind" or "infront" of it have 
		/// higher z-index than the container's default one 
		///</summary>
		///<param name="zindex" type="Number" integer="true"></param>
		this._zIndex = zindex;

	},

	get_position: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.position">
		/// returns the $IG.DropDownPopupPosition that is currently used for the dropdown behavior
		///</summary>
		///<value type="Infragistics.Web.UI.DropDownPopupPosition">
		/// the $IG.DropDownPopupPosition that is currently set 
		///</value>
		return this._position;
	},

	set_position: function(position)
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.position">
		/// position is of type $IG.DropDownPopupPosition. This is the position of the dropdown container relative to the source element
		///</summary>
		///<param name="position" type="$IG.DropDownPopupPosition" domElement="false"></param>
		///<remarks>
		///
		///</remarks>
		this._position = position;
	},

	get_enableAutomaticPositioning: function()
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.enableAutomaticPositioning">
	/// container will be automatically positioned on the opposite direction, if space is not present on the currently set direction 
	// that is, it will be positioned above, if there is no space below the source
	///</summary>
	///<value type="Boolean"> value indicating whether automatic positioning is enabled or not </value>
		return this._enableAutomaticPositioning;
	},

	set_enableAutomaticPositioning: function(enabled)
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.enableAutomaticPositioning">
		/// container will be automatically positioned on the opposite direction, if space is not present on the currently set direction 
		/// that is, it will be positioned above, if there is no space below the source
		///</summary>
		///<param name="enabled" type="Boolean"></param>
		this._enableAutomaticPositioning = enabled;
	},

	get_enableMovingTargetWithSource: function()
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.enableMovingTargetWithSource">
	/// when the parent of the source element changes its position, target will also move accordingly (example: when source is placed in WebDialogWindow and we are moving it)
	///</summary>
	///<value type="Boolean"> value indicating whether target will be automatically moved when the parent of the source element changes its position </value>
		return this._enableMovingTargetWithSource;

	},

	set_enableMovingTargetWithSource: function(enabled)
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.enableMovingTargetWithSource">
		/// when the parent of the source element changes its position, target will also move accordingly (example: when source is placed in WebDialogWindow and we are moving it)
		///</summary>
		///<param name="enabled" type="Boolean"></param>
		this._enableMovingTargetWithSource = enabled;

		if (this._enableMovingTargetWithSource)
		{

			clearInterval(this._closeCheckID);
			this._checkDelegate = Function.createDelegate(this, this._onCheckPosition);
			this._sourceLocation = $util.getLocation(this._sourceElement);
			this._sourceBounds = Sys.UI.DomElement.getBounds(this._sourceElement);
			this._closeCheckID = setInterval(this._checkDelegate, 200);

		} else
		{
			clearInterval(this._closeCheckID);
		}

	},

	get_enableAnimations: function()
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.enableAnimations">
	/// animations are performed on the target container 
	///</summary>
	///<value type="Boolean"> value indicating if animations on the target container will be enabled or no </value>
		return this._enableAnimations;
	},

	set_enableAnimations: function(enableAnimations)
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.enableAnimations">
		/// enables disables animations of the dropdown container - enableAnimations must be true or false
		///</summary>
		///<param name="enableAnimations" type="boolean" domElement="false"></param>
		///<remarks>
		///
		///</remarks>
		this._enableAnimations = enableAnimations;
	},

	get_animationType: function()
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.animationType">
	/// returns the animation type ($IG.AnimationEquationType): Linear, EaseInOut, etc. 
	///</summary>
	///<value type="Infragistics.Web.UI.AnimationEquationType"> indicates the animation type </value>
		return this._animationType;
	},

	set_animationType: function(animationType)
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.animationType">
		/// sets the type of animation for the drop down container
		///</summary>
		///<param name="animationType" type="$IG.AnimationEquationType" domElement="false"></param>
		///<remarks>
		///
		///</remarks>
		this._animationType = animationType;
	},

	get_animationDurationMs: function()
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.animationDurationMs">
	/// returns the number of milliseconds during which the animation will play
	///</summary>
	///<value type="Number" integer="true"> animation duration in milliseconds </value>
		return this._animationDurationMs;
	},

	set_animationDurationMs: function(duration)
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.animationDurationMs">
		/// sets the number of milliseconds during which the animation will play
		///</summary>
		///<param name="duration" type="Number" integer="true" domElement="false"></param>
		///<remarks>
		///
		///</remarks>
		this._animationDurationMs = duration;
	},

	get_offsetX: function()
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.offsetX">
	/// returns the number of pixels by which the dropdown container will be offset on the x axis
	///</summary>
	///<value type="Number" integer="true"> number of pixels by which the dropdown container will be offset on the x axis </value>
		return this._offsetX;
	},

	set_offsetX: function(offsetX)
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.offsetX">
		/// sets the number of pixels by which the dropdown container will be offset on the x axis
		///</summary>
		///<param name="offsetX" type="Number" integer="true" domElement="false"></param>
		///<remarks>
		///
		///</remarks>
		this._offsetX = offsetX;
	},

	get_offsetY: function()
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.offsetY">
	/// returns the number of pixels by which the dropdown container will be offset on the y axis
	///</summary>
	///<value type="Number" integer="true"> number of pixels by which the dropdown container will be offset on the y axis </value>
		return this._offsetY;
	},

	set_offsetY: function(offsetY)
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.offsetY">
		/// returns the number of pixels by which the dropdown container will be offset on the y axis
		///</summary>
		///<param name="offsetY" type="Number" integer="true" domElement="false"></param>
		///<remarks>
		///
		///</remarks>
		this._offsetY = offsetY;
	},

	get_offScreen: function()
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.offScreen">
	/// returns whether the dropdown container will be off the screen on its next appearance. If this is true, and the positioning is set to Default
	/// i.e. AUTO, then the position of the dropdown will be readjusted so that it is visible on the screen 
	///</summary>
	///<value type="Boolean"> indicates whether the target cannot be fully shown on the screen (because some part of it will be hidden or scrollbars will need to be shown </value>
		return this._offScreen;
	},

	set_offScreen: function(offScreen)
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.offScreen">
		/// sets whether the drop down container is off the screen or not
		///</summary>
		///<param name="offScreen" type="boolean" domElement="false"></param>
		///<remarks>
		///
		///</remarks>
		this._offScreen = offScreen;
	},

	get_visibleOnFocus: function()
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.visibleOnFocus">
	/// returns whether the dropdown container should show if the source gains focus
	///</summary>
	///<value type="Boolean"> indicates if the dropdown container should show if the source gains focus </value>
		return this._visibleOnFocus;
	},

	set_visibleOnFocus: function(visibleOnFocus)
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.visibleOnFocus">
		///  sets whether the dropdown container should show if the source gains focus
		///</summary>
		///<param name="visibleOnFocus" type="Boolean" domElement="false"></param>
		///<remarks>
		///
		///</remarks>
		this._visibleOnFocus = visibleOnFocus;
	},

	get_visibleOnBlur: function()
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.visibleOnBlur">
		/// returns whether the dropdown container should hide if the source loses focus
		///</summary>
		///<value type="Boolean"> indicates if the dropdown container should hide if the source loses focus </value>
		return this._visibleOnBlur;
	},

	set_visibleOnBlur: function(visibleOnBlur)
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.visibleOnBlur">
		/// sets whether the dropdown container should hide if the source loses focus
		///</summary>
		///<param name="visibleOnBlur" type="Boolean" domElement="false"></param>
		///<remarks>
		///
		///</remarks>
		this._visibleOnBlur = visibleOnBlur;
	},

	get_isAnimating: function()
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.isAnimating">
	/// if true, animation is in progress
	///</summary>
	///<value type="Boolean">indicates whether there is animation in progress </value>
		if (this._dropDownAnimation)
			return this._dropDownAnimation.get_isAnimating();
		else
			return false;
	},

	get_visibleOnMouseOver: function()
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.visibleOnMouseOver">
	/// returns whether the dropdown container should show if mouse over is executed on the source
	///</summary>
	///<value type="Boolean"> indicates if the dropdown container should show if mouse over is executed on the source </value>
		return this._visibleOnMouseOver;
	},

	set_visibleOnClick: function(visibleOnClick)
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.visibleOnClick">
		/// sets whether the dropdown container should show if click is executed on the source
		///</summary>
		///<param name="visibleOnClick" type="Boolean" domElement="false"></param>
		///<remarks>
		///
		///</remarks>
		this._visibleOnClick = visibleOnClick;
	},

	get_visibleOnClick: function()
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.visibleOnClick">
	/// returns whether the dropdown container should show if click is executed on the source
	///</summary>
	///<value type="Boolean">indicates if the dropdown container should show if click is executed on the source</value>
		return this._visibleOnClick;
	},

	set_visibleOnMouseOver: function(visibleOnMouseOver)
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.visibleOnMouseOver">
		/// sets whether the dropdown container should show if mouse over is executed on the source
		///</summary>
		///<param name="visibleOnMouseOver" type="Boolean" domElement="false"></param>
		///<remarks>
		///
		///</remarks>
		this._visibleOnMouseOver = visibleOnMouseOver;
	},

	get_visibleOnKeyDown: function()
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.visibleOnKeyDown">
	/// returns whether the dropdown container should show if key down is executed on the source
	///</summary>
	///<value type="Boolean"> indicates if the dropdown container should show if key down is executed on the source</value>
		return this._visibleOnKeyDown;
	},

	set_visibleOnKeyDown: function(visibleOnKeyDown)
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.visibleOnKeyDown">
		/// sets whether the dropdown container should show if key down is executed on the source
		///</summary>
		///<param name="visibleOnKeyDown" type="Boolean" domElement="false"></param>
		///<remarks>
		///
		///</remarks>
		this._visibleOnKeyDown = visibleOnKeyDown;
	},

	get_dropDownIsChild: function()
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.dropDownIsChild">
	/// returns whether or not the dropdown container is the first child of the source element, or whether it is absolutely positioned
	/// anywhere on the page (normally the appended to the form as a sibling)
	///</summary>
	///<value type="Boolean"> indicates if dropdown container will be first child of the source element or not (abs positioned and attached to the form)</value>
		return this._dropDownIsChild;
	},

	get_visible: function()
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.visible">
	/// whether the dropdown container is currently visible (shown) or not
	///</summary>
	///<value type="Boolean"> indicates if the dropdown container is currently visible (shown) or not</value>
		return this._visible;
	},

	set_visible: function(visible)
	{
		///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.visible">
		/// causes the dropdown container to show and hide
		/// NOTE: calling this function actually *CAUSES* the dropdown to show and hide
		/// it does not only modify the contents of the "_visible" variable
		///</summary>
		///<param name="visible" type="Boolean"></param>
		///<remarks>
		/// Do we fire these events if the dropdown is already visible / hidden ? 
		///</remarks>
		// denotes whether the "ing" event will be canceled or not

		var cancelEvent = false;

		this._sourceLocation = $util.getLocation(this._sourceElement);

		// return immediately if there is an ongoing animation
		if (this._dropDownAnimation && this._dropDownAnimation.get_isAnimating())
		{
			return;
		}
		
		if (this._visChange)
		{
			if (!visible && this._visChange > 0)
				this._visChange++;
			return;
		}
		this._visChange = visible ? 1 : -1;
		if (visible)
		{
			// fire setting visible event
			cancelEvent = this.get_Events()._fireEvent("SettingVisible", this);

		} else
		{
			// fire setting hidden event
			cancelEvent = this.get_Events()._fireEvent("SettingHidden", this);
		}

		// we need to be able to read both the current value as well as the new value
		// var tmpVisible = this._visible;
		// this._visible = visible;

		
		if (!cancelEvent)
		{
			// if the dropdown is hidden, and we want it to show, GO
			if (visible && !this._visible)
			{
				this.__showDropDown();

				// if the dropdown is currently visible, and we want it to hide, GO
			} else if (!visible && this._visible)
			{
				this.__hideDropDown();
			}

			// do we fire these events if the dropdown is already visible / hidden ? 
			if (visible)
			{
				// fire set visible event
				this.get_Events()._fireEvent("SetVisible", this); // event after the dropdown has appeared

			} else
			{
				// fire set hidden event
				this.get_Events()._fireEvent("SetHidden", this); // event after the dropdown has been hidden
			}

			// if animations are enabled then we flip the visible flag in the doEnd() method of the 
			// drop down animation object. Since the dropdown animation constantly reads this flag, and uses setTimeout/interval, if we change it here
			// it will pick the wrong value
			if (!this._enableAnimations)
			{
				this._visible = visible;
			}

		}
		
		visible = this._visChange;
		delete this._visChange;
		if (visible > 1)
			this.set_visible(false);
	},

	get_Events: function()
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.Events">
	/// Returns a reference to the Infragistics.Web.UI.DropDownEvents object, which contains all the events of the behavior.
	///</summary>
	///<returns type="Infragistics.Web.UI.DropDownEvents"></returns>
		return this._events;
	},

	


	

	// not currently used
	getBounds: function()
	{
	///<summary locid="M:J#Infragistics.Web.UI.DropDownBehavior.getBounds">
	/// 
	///</summary>
		return this._bounds;
	},

	triggerVisibility: function()
	{
	///<summary locid="M:J#Infragistics.Web.UI.DropDownBehavior.triggerVisibility">
	/// if the dropdown is currently hidden, cause it to show. If it is shown, cause it to hide
	///</summary>
		if (this._visible)
		{
			this.set_visible(false);
		} else
		{
			this.set_visible(true);
		}

	},

	set_containerMaxHeight: function(maxHeight, containerContent, container)
	{
	///<summary locid="P:J#Infragistics.Web.UI.DropDownBehavior.containerMaxHeight">
	/// maximum height to which the target container will grow before scrollbars are displayed for it, and it gets fixed height 
	///</summary>
	///<param name="maxHeight" type="Number" integer="true"> the maximum height value </param>
	///<param name="containerContent" domElement="true"> the container contents (usually that's first child element of the container)</param>
	///<param name="container" domElement="true"> the container DOM element</param>
        var realContainer = this.get_enableAnimations() ? this._animationsContainer : this._targetContainer;
        
		realContainer.style.left = -10000;
		realContainer.style.top = -10000;
		realContainer.style.display = 'block';
		realContainer.style.visibility = 'visible';

		if (maxHeight <= containerContent.offsetHeight)
		{
			container.style.height = maxHeight + 'px';
		}

		realContainer.style.left = 0;
		realContainer.style.top = 0;
		realContainer.style.display = 'none';
		realContainer.style.visibility = 'hidden';

	},

	init: function()
	{
	///<summary locid="M:J#Infragistics.Web.UI.DropDownBehavior.init">
	///  registers event handlers, initializes animation object (and animation container), sets the initial styles on the animation and target containers
	/// if the dropDownIsChild flag is true, we attach the dropdown container as a direct first child of the source element
	/// if not, it is absolutely positioned anywhere on the page and its position is calculated and adjusted using marginTop and MarginLeft
	///</summary>
	///<remarks>
	///
	///</remarks>
		// attach handlers for the actual element events

		if (this._mouseUpDelegate)
		{
			$addHandler(this._sourceElement, 'mouseup', this._mouseUpDelegate);
			$addHandler(this._sourceElement, 'click', this._mouseClickDelegate);
			$addHandler(this._sourceElement, 'mouseover', this._mouseOverDelegate);
			$addHandler(this._sourceElement, 'mousedown', this._mouseDownDelegate);
			$addHandler(this._sourceElement, 'keydown', this._keyDownDelegate);

			$addHandler(this._sourceElement, 'keyup', this._keyUpDelegate);
			$addHandler(this._sourceElement, 'focus', this._focusDelegate);
			$addHandler(this._sourceElement, 'blur', this._blurDelegate);
		}

		
		if (!this._noMove)
		{
			if (this._dropDownIsChild)
			{

				this._sourceElement.appendChild(this._targetContainer);
			} else
			{

				document.forms[0].appendChild(this._targetContainer);
			}
		}

		this._targetContainer.style.display = 'block';
		this._targetContainer.style.visibility = 'visible';
		//this._targetContainer.style.position= 'relative'; 
		this._targetContainer.style.position = ''; // very important for IE overflow:hidden bug. We must not set relative positioning !
		// stores the targetContainer height, so that it can be used later on - in case the actual height gets modified by animations and so on
		this._targetBounds = Sys.UI.DomElement.getBounds(this._targetContainer);
		this._containerHeight = this._targetBounds.height; // for convenience

		this._dropDownAnimation = new $IG.DropDownAnimation(this);
		this._dropDownAnimation.set_duration(this._animationDurationMs); // animation duration in milliseconds

		// look in the variable declaration for _animationsContainer for more info
		if (this._enableAnimations)
		{
			this._animationsContainer = document.createElement("div");
			this._animationsContainer.id = this._targetContainer.id + "_animations";
			this._animationsContainer.style.display = 'none';
			this._animationsContainer.style.visibility = 'hidden';
			this._animationsContainer.style.overflow = 'hidden'; // very important: so that the actual contents get correctly displayed while animating
			this._animationsContainer.style.position = 'absolute';
		}

		// choose the correct container to manipulate depending on whether animations are enabled or not
		// remember that for animations we use the approach where we create a separate animations container that is inserted
		// as the parent of our targetContainer. The target container has no knowledge
		// of the animations container
		var container = (this._enableAnimations) ? this._animationsContainer : this._targetContainer;

		
		if (!this._noMove)
		{
			if (this._dropDownIsChild)
			{
				this._sourceElement.insertBefore(container, this._sourceElement.firstChild);
			} else
			{
				// append as a first element of the first form !!!
				// if we append directly after the source (as a sibling), and the two
				// elements are in a scrolling container, some elements can still display
				// above the container !!! i.e. the dropdown container must be outside the scrolling container
				// for this to work properly
				document.forms[0].appendChild(container);
			}
		}


		if (this._enableAnimations)
		{

			$util.setAbsoluteHeight(this._animationsContainer, 0);
			// if animations are enabled, we don't need to change the style of the targetContainer every time
			// it will just be controlled indirectly by the animationContainer's style
			this._containerHeight = this._targetBounds.height;
			//$util.setAbsoluteHeight(this._animationsContainer, this._targetBounds.height); // inherit the target container's height and width
			$util.setAbsoluteWidth(this._animationsContainer, this._targetBounds.width);

			// finally add this move handler, once we have attached the animations container - if any
			// background iFrame move handler (so that the iframe behind the popup contianer always stays
			// properly positioned
			if (this._moveDelegate)
				$addHandler(this._animationsContainer, 'move', this._moveDelegate);

			// insert the animations container as a parent of the targetContainer
			this._animationsContainer.appendChild(this._targetContainer);

		} else
		{

			// if animations are disabled, directly change the style of the target container so that it is initially hidden
			this._targetContainer.style.display = 'none';
			this._targetContainer.style.visibility = 'hidden';
			this._targetContainer.style.position = 'absolute';
			if (this._moveDelegate)
				$addHandler(this._targetContainer, 'move', this._moveDelegate);
		}

	},

	dispose: function()
	{
	///<summary locid="M:J#Infragistics.Web.UI.DropDownBehavior.dispose">
	/// to be used internally 
	///</summary>

		// A.T: Bug #9792 Bug first , stop the animation, if any
		this._dropDownAnimation.stop();
		this._dropDownAnimation.onEnd();
		if (this._mouseUpDelegate)
		{
			// remove event handlers
			
			try
			{
				$removeHandler(this._sourceElement, 'mouseup', this._mouseUpDelegate);
			} catch (e) { }

			
			try
			{
				$removeHandler(this._sourceElement, 'click', this._mouseClickDelegate);
			} catch (e) { }

			
			try
			{
				$removeHandler(this._sourceElement, 'mouseover', this._mouseOverDelegate);
			} catch (e) { }

			
			try
			{
				$removeHandler(this._sourceElement, 'mousedown', this._mouseDownDelegate);
			} catch (e) { }

			
			try
			{
				$removeHandler(this._sourceElement, 'keydown', this._keyDownDelegate);
			} catch (e) { }

			
			try
			{
				$removeHandler(this._sourceElement, 'keyup', this._keyUpDelegate);
			} catch (e) { }

			
			try
			{
				$removeHandler(this._sourceElement, 'focus', this._focusDelegate);
			} catch (e) { }

			
			try
			{
				$removeHandler(this._sourceElement, 'blur', this._blurDelegate);
			} catch (e) { }

			try
			{ 
				$removeHandler(this._targetContainer, 'move', this._moveDelegate);
			} catch (e) { }
		}
		delete this._mouseUpDelegate;
		delete this._mouseClickDelegate;
		delete this._mouseOverDelegate;
		delete this._mouseDownDelegate;
		delete this._keyDownDelegate;
		delete this._keyUpDelegate;
		delete this._focusDelegate;
		delete this._blurDelegate;
		delete this._moveDelegate;

		// reset height, reset the animations container
		delete this._events;
		delete this._containerHeight;
		delete this._dropDownAnimation;
		delete this._animationsContainer;

		// clears the timeout for the automatic repositioning of the target container
		clearInterval(this._closeCheckID);
		delete this._closeCheckID;
		delete this._checkDelegate;
		




		// breaking connection to sourceElement and targetContainter
		this._sourceElement = null;
		this._targetContainer = null;

		// clear all used variables as well 
		delete this._position;
		this._outerContainer = null;
		delete this._offsetX;
		delete this._offsetY;
		delete this._containerHeight;
		delete this._offScreen;
		delete this._enableAutomaticPositioning;
		delete this._enableMovingTargetWithSource;
		delete this._enableAnimations;
		delete this._animationType;
		delete this._visible;
		delete this._visibleOnFocus;
		delete this._visibleOnBlur;
		delete this._visibleOnMouseOver;
		delete this._visibleOnClick;
		delete this._visibleOnKeyDown;
		delete this._dropDownAnimation;
		delete this._animationDurationMs;
		delete this._zIndex;
		delete this._targetBounds;
		delete this._dropDownIsChild;
		delete this._extraOuterContainers;
		delete this._movingTargetAllowance;
	},	

	

	get_extraOuterContainers: function ()
	{
		///<summary locid="M:J#Infragistics.Web.UI.DropDownBehavior.get_extraOuterContainers">
		/// Returns an array of extra outer containers that the drop down could be in that are scrollable
		///</summary>
		return this._extraOuterContainers;
	},
	set_extraOuterContainers: function (extraContainers)
	{
		///<summary locid="M:J#Infragistics.Web.UI.DropDownBehavior.get_extraOuterContainers">
		/// Sets the array of extra outer containers that the drop down could be in that are scrollable
		///</summary>
		this._extraOuterContainers = extraContainers;
	},

    
    get_movingTargetAllowance: function ()
    {
        ///<summary locid="M:J#Infragistics.Web.UI.DropDownBehavior.movingTargetAllowance">
        /// Returns an integer for how many pixels tolerance should be allowed before hiding the drop down
        /// when the source is in a scrollable container
        ///</summary>
        return this._movingTargetAllowance;
    },
    set_movingTargetAllowance: function (allowance)
    {
        ///<summary locid="M:J#Infragistics.Web.UI.DropDownBehavior.movingTargetAllowance">
        /// Sets an integer for how many pixels tolerance should be allowed before hiding the drop down
        /// when the source is in a scrollable container
        ///</summary>
        this._movingTargetAllowance = allowance;
    },

	//adjustPopupPosition: function(bounds)
	//{
	//    
	//}

	
    
	_onCheckPosition: function()
	{

		var oldPos = this._sourceLocation;
		var oldBounds = this._sourceBounds;

		// A.T. if true, it means that the dropdown is opened for some element (source) that is movable within a scrolling container
		// i.e. imagine a row edit template, whose parent is the row itself - hence, while the row is scrolled, if the dropdown
		// container and its row go off the visible grid area, we should close the dropdown 
		var shouldHideFromContainer = false;

		try
		{
			var currentPos = $util.getLocation(this._sourceElement);
			var currentBounds = Sys.UI.DomElement.getBounds(this._sourceElement);

			// if this._outerContainer is defined, check whether the source element falls in the boundaries of the outerContainer
			if (this._outerContainer)
			{
				var outerContainerBounds = Sys.UI.DomElement.getBounds(this._outerContainer);
				var outerContainerPos = $util.getLocation(this._outerContainer);
                
				if (currentPos.y + currentBounds.height > outerContainerBounds.height + outerContainerPos.y + this._movingTargetAllowance || currentPos.y + this._movingTargetAllowance < outerContainerPos.y)
				{
					shouldHideFromContainer = true;
				}
			}
			

			for (var x = 0; this._extraOuterContainers != null && x < this._extraOuterContainers.length && !shouldHideFromContainer; ++x)
			{
                if (this._extraOuterContainers[x])
                {
				    var outerContainerBounds = Sys.UI.DomElement.getBounds(this._extraOuterContainers[x]);
				    var outerContainerPos = $util.getLocation(this._extraOuterContainers[x]);
                    
				    if (currentPos.y + currentBounds.height > outerContainerBounds.height + outerContainerPos.y + this._movingTargetAllowance || currentPos.y + this._movingTargetAllowance < outerContainerPos.y)
				    {
					    shouldHideFromContainer = true;
				    }
                }
			}

		}
		catch (e)
		{
			return;
		}

        if (oldPos.x != currentPos.x || oldPos.y != currentPos.y || currentBounds.width != oldBounds.width || currentBounds.height != oldBounds.height)
		{

			if ((currentBounds.width <= 0 && currentBounds.height <= 0) || shouldHideFromContainer)
			{
				// source element is hidden, set the target to hidden as well
				this._targetContainer.style.visibility = 'hidden';
				this._targetContainer.style.display = 'none';

			} 
            else
			{
				// reopen the dropdown
				if (this.get_visible())
				{
					this.set_visible(false);
					this.set_visible(true);
				}
			}

			this._sourceLocation = currentPos;
			this._sourceBounds = currentBounds;
		}
	},

	

	_onMove: function()
	{
		/// <summary>
		/// Track the popup's movements so the hidden IFrame (IE6 only) can
		/// be moved along with it
		/// </summary>
		var container = (this._enableAnimations) ? this._animationsContainer : this._targetContainer;
		var top = container.style.top, left = container.style.left, style = this._childFrame ? this._childFrame.style : null;
		if (style && (style.top != top || style.left != left))
		{
			style.top = top;
			style.left = left;
		}
	},

	_mouseUpHandler: function(e)
	{
		// do we need this handler ? mouseClick should be enough
	},

	_mouseClickHandler: function(e)
	{
		// this.__handleTrigger(e);
	},

	_mouseOverHandler: function(e)
	{
		// cause the dropdown to show, if we have enabled this behavior via a set_visibleOnMouseOver(true) call
		if (this._visibleOnMouseOver)
		{
			this.__handleVisible(e);
		}
	},

	_mouseDownHandler: function(e)
	{
		// cause the dropdown to show, if we have enabled this behavior via a set_visibleOnMouseDown(true) call and mouseDown is invoked on the source
		if (this._visibleOnMouseDown)
		{
			this.__handleTrigger(e);
		}
	},

	_keyDownHandler: function(e)
	{
		// cause the dropdown to show, if we have enabled this behavior via a set_visibleOnKeyDown(true) call and keyDown is invoked on the source
		if (this._visibleOnKeyDown)
		{
			this.__handleVisible(e);
		}
	},

	_keyUpHandler: function(e)
	{
		// cause the dropdown to hide, if we have enabled this behavior via a set_visibleOnKeyDown(true) call and keyUp is invoked in the source
		if (this._visibleOnKeyDown)
		{
			this.__handleHidden(e);
		}
	},

	_focusHandler: function(e)
	{
		// cause the dropdown to show, if the source element gains focus
		if (this._visibleOnFocus)
		{
			this.__handleVisible(e);
		}
	},

	_blurHandler: function(e)
	{

		// cause the dropdown to hide, if the source element loses focus
		if (this._visibleOnBlur)
		{
			this.__handleHidden(e);
		}
	},

	


	

	_addBackgroundIFrame: function()
	{
		/// <summary>
		/// Add an empty IFRAME behind the popup (for IE6 only) so that SELECT, etc., won't
		/// show through the popup.
		/// </summary>
		if (!$util.IsIE)
			return;
		// select the correct dropdown container depending on whether animations are enabled or not
		var v, s1, iframe = this._childFrame,
			container = (this._enableAnimations) ? this._animationsContainer : this._targetContainer,
			s0 = container.style;
		// Create the child frame if it wasn't found
		if (!iframe)
		{
			this._childFrame = iframe = document.createElement("iframe");
			
			
			v = document.domain == document.location.hostname ? "javascript:'<html></html>';" :
				"javascript:'<script>window.onload=function(){document.write(\\'<script>document.domain=\\\"" +
				document.domain + "\\\";<\\\\/script>\\');document.close();};<\\/script>'";
			iframe.src = v;
			s1 = iframe.style;
			s1.position = "absolute";
			s1.display = "none";
			iframe.scrolling = "no";
			iframe.frameBorder = "0";
			iframe.tabIndex = "-1";
			s1.filter = "progid:DXImageTransform.Microsoft.Alpha(style=0,opacity=0)";
			container.parentNode.insertBefore(iframe, container);
		}
		else
			s1 = iframe.style;
		if (s0.top)
			s1.top = s0.top;
		if (s0.left)
			s1.left = s0.left;
		s1.marginTop = s0.marginTop;
		s1.marginLeft = s0.marginLeft;
		s1.width = s0.width;
		s1.height = s0.height;
		s1.display = s0.display;
		v = container.currentStyle ? container.currentStyle.zIndex : null;
		s1.zIndex = v || s0.zIndex;
	},

	/// sets the drop down as a child of the target
	_attach: function()
	{
		
		if (!this._noMove)
		{
			if (!this._dropDownIsChild)
			{
				this._sourceElement.appendChild(this._targetContainer);
			}
		}
	},

	/// moves back the drop down into the animations frame (if any)
	_detach: function()
	{
		
		if (!this._noMove)
		{
			if (!this._dropDownIsChild)
			{
				if (this.get_enableAnimations())
				{

					this._animationsContainer.appendChild(this._targetContainer);
				}
				else
				{
					document.forms[0].appendChild(this._targetContainer);
				}
			}
		}
	},

	_setAnimationEndListener: function(element)
	{
		this._animationEndListener = element;
	},

	_adjustDropDownPosition: function(targetBounds, sourceBounds, currentX, currentY)
	{
		/// <summary>
		/// when the positioning is default/auto, and we detect that the dropdown 
		/// cannot be displayed below, we flip it to be displayed above the source element
		/// </summary>
		/// <param name="targetBounds" type="Sys.UI.Bounds" domElement="false">
		/// bounds of the target container
		/// </param>
		/// <param name="sourceBounds" type="Sys.UI.Bounds" domElement="false">
		/// bounds of the source element
		/// </param>
		/// <param name="currentX" type="Number" integer="true" domElement="false">
		/// current marginLeft offset
		/// </param>
		/// <param name="currentY" type="Number" integer="true" domElement="false">
		/// current marginTop offset
		/// </param>
		/// <remarks>
		/// </remarks>

		// whether the dropdown will be off the screen or not
		this._offScreen = false;
		var x = currentX, y = currentY;
		// target container bounds

		// retrieve the correct container reference depending on whether we have 
		// animations enabled or not
		var container = (this._enableAnimations) ? this._animationsContainer : this._targetContainer;

		// the current position (left,top) of the dropdown container
		// var targetContainerPosition = $util.getPosition(container);
		var targetContainerPosition = $util.getLocation(container);

		//   var sourceElementPosition = $util.getPosition(this._sourceElement);
		var sourceElementPosition = $util.getLocation(this._sourceElement);
		// x = targetContainerPosition.x;
		// y = sourceElementPosition.y - targetContainerPosition.y;

		// if reset is set to true, we will modify the container's marginTop property
		var reset = false;

		// detectoverflow on the bottom
		// note that it is very important that we account for the body scrollTop as well !!!
		var windowHeight = 0;
		var windowScrollTop = 0;

		if (document.compatMode == "BackCompat")
		{

			windowHeight = document.body.clientHeight;
			windowScrollTop = document.body.scrollTop;

		} else
		{
			// quirks
			windowHeight = window.innerHeight;
			windowScrollTop = window.pageYOffset;

			if ($util.IsIE)
			{
				windowHeight = document.documentElement.clientHeight;
				windowScrollTop = document.documentElement.scrollTop;
			}

		}
		
		var height = sourceBounds.height;
		var upDown = this.get_position() != $IG.DropDownPopupPosition.Left && this.get_position() != $IG.DropDownPopupPosition.Right;
		var topCheck = upDown ? height : 0;
		windowHeight -= 4;

		// A.T. Bug #9407 - check if outerContainer was defined , in that case our boundaries
		// aren't the browser window or frame itself, but the container (i.e. grid fixed div)
		// so we should check the target location against these container bounds

		if (this._outerContainer)
		{

			// algorithm: 
			// 1. the target container is bigger than the outer container => show it below (always)

			// 2. the target container can be shown below (fully ) => show it below

			// 3. the target container cannot be shown below (will go off the bounds) , but: 
			// 3. a) will also go off the bounds if shown above => show it below
			// 3. b) will not go off the bounds if shown above => show it above

			// targetBounds
			// targetContainerPosition

			var outerContainerPos = $util.getLocation(this._outerContainer);
			var outerContainerBounds = Sys.UI.DomElement.getBounds(this._outerContainer);

			if (targetBounds.height < outerContainerBounds.height)
			{
				if (targetContainerPosition.y + targetBounds.height > outerContainerPos.y + outerContainerBounds.height)
				{
					// try to show it above
					// 3.a)
					if (targetContainerPosition.y - targetBounds.height > outerContainerPos.y)
					{
						// flip the container position
						y -= targetBounds.height;

						if (upDown)
						{
							y -= height;
						} else
						{
							y += height;
						}

						reset = true;
						this._offScreen = true;
						y -= this._offsetY * 2; // account for the "Y" offset, but in the reverse direction
						// note that since we have already accounted for it, we need to do this twice now   
					}
				}
			}

		} else if (targetBounds.height + topCheck + sourceElementPosition.y > windowHeight + windowScrollTop)
		{
			// flip the container position
			y -= targetBounds.height;

			if (upDown)
			{
				y -= height;
			} else
			{
				y += height;
			}

			reset = true;
			this._offScreen = true;
			y -= this._offsetY * 2; // account for the "Y" offset, but in the reverse direction
			// note that since we have already accounted for it, we need to do this twice now
		}

		if (reset)
		{
			container.style.marginTop = y + 'px';
		}

	},

	


	

	// helper method
	__handleHidden: function(e)
	{

		if (this._visible)
		{
			this.set_visible(false);
		}
	},

	// helper method
	__handleVisible: function(e)
	{
		if (!this._visible)
		{
			this.set_visible(true);
		}
	},

	// helper method
	__handleTrigger: function(e)
	{
		if (this._visible)
		{
			this.set_visible(false);
		} else
		{
			this.set_visible(true);
		}
	},

	__showDropDown: function()
	{
		/// <summary>
		/// Causes the dropdown to show
		/// </summary>

		// retrieve the correct container reference depending on whether we have animations enabled or not
		var container = (this._enableAnimations) ? this._animationsContainer : this._targetContainer;

		// initialize the container before we show it
		container.style.position = 'absolute';
		container.style.display = '';
		container.style.visibility = 'visible';
		container.style.zIndex = $util._zIndexTop(this._sourceElement, this._zIndex);
		

		




		var x = 0, y = 0; // marginLeft, marginTop

		// default is left bottom
		y = Sys.UI.DomElement.getBounds(this._sourceElement).height;
		
		// A.T. 16th April - Fix for bug #30748 - DropDown doesn�t drop down when it is not in the first tab of the Aikido WebTab
		//recalc targetBounds if initial are zero:
		if (this._targetBounds.height == 0)
		{
			this._targetBounds = Sys.UI.DomElement.getBounds(this._targetContainer);
			this._containerHeight = this._targetBounds.height;
			if (this._enableAnimations)
			{
				$util.setAbsoluteWidth(this._animationsContainer, this._targetBounds.width);
			}
		}

		var targetBounds = this._targetBounds;
		var sourceBounds = Sys.UI.DomElement.getBounds(this._sourceElement);

		// if we want the container to be positioned anywhere above the source element
		var isTop = this._position == $IG.DropDownPopupPosition.TopLeft || this._position == $IG.DropDownPopupPosition.TopRight;

		// handle positioning
		switch (this._position)
		{

			case $IG.DropDownPopupPosition.Default:
				// default is left bottom . Also handles AUTO
				break;
			case $IG.DropDownPopupPosition.Center: // default is bottom
				x += sourceBounds.width / 2;
				x -= targetBounds.width / 2;
				break;
			case $IG.DropDownPopupPosition.Left:
				x -= targetBounds.width;
				y -= sourceBounds.height;
				break;
			case $IG.DropDownPopupPosition.Right:
				x += sourceBounds.width;
				y -= sourceBounds.height;
				break;
			case $IG.DropDownPopupPosition.BottomLeft:
				// this is the default positioning
				//x = 
				//y = 
				break;
			case $IG.DropDownPopupPosition.BottomRight:
				x += sourceBounds.width;
				x -= targetBounds.width;
				//y = 
				break;
			case $IG.DropDownPopupPosition.TopLeft:
				// x = 0;
				y -= targetBounds.height;
				y -= sourceBounds.height;
				break;
			case $IG.DropDownPopupPosition.TopRight:
				x += sourceBounds.width;
				x -= targetBounds.width;
				y -= targetBounds.height;
				y -= sourceBounds.height;
				break;
			default:
				break;
		}

		//if(!this._dropDownIsChild)
		//{
		container.style.marginLeft = '';
		container.style.marginTop = '';

        //A.T. fix for bugs #58561 and #58647 - The drop down editor inside child bands opens with offset after scrolling in the h grid / The cursor is being displayed in an incorrect location when clicking on the dropdown
		//var p0 = $util.getLocation(this._sourceElement), p1 = $util.getLocation(container);
		
		
		var p0 = $util.getPosition(this._sourceElement, 1, 6), p1 = $util.getPosition(container, 1, 6);

		// A.T. Fix for Bug 9553
		if (Sys.Browser.agent == Sys.Browser.Safari && this._sourceElement.nodeName == 'TD')
		{
			y -= this._sourceElement.offsetTop;
			y += this._sourceElement.parentNode.offsetTop;
		}
		
		




		//I.I.: 87265, scrolling offset is being taken in account
        // K.D. February 20th, 2012 Bug #101028 & #101165 DropDownItems’ container is not displayed in correct position under Chrome and Safari. Reverting the fix done for bug #87265 because the issue there is the height of the IFrame defined in %
        x += p0.x - p1.x;
		y += p0.y - p1.y;

		// A.T: BR35639: Dropdown framework: scrollX and scrollY are not taken into account
		//x -= p0.scrollX;
		//y -= p0.scrollY;
		//}

		// account for offsetX and offsetY
		x += this._offsetX;
		if (isTop)
		{
			y -= this._offsetY;
		} else
		{
			y += this._offsetY;
		}
		
		
		var oy, fixHeight = !this._outerContainer && !isTop && this._enableAutomaticPositioning ? this._targetBounds.height : 0;
		if (fixHeight)
		{
			oy = $util.getStyleValue(null, 'overflowY', container);
			container.style.overflowY = 'hidden';
			container.style.height = '1px';
		}
		container.style.marginLeft = x + 'px';
		container.style.marginTop = y + 'px';

		// adjust the dropdown position in case it will display off the screen
		if (!isTop && this._enableAutomaticPositioning)
		{
			this._adjustDropDownPosition(targetBounds, sourceBounds, x, y);
			
			
			if (fixHeight)
			{
				container.style.height = fixHeight + 'px';
				container.style.overflowY = oy;
			}
		}

		
		this._targetContainer.style.display = "";
		this._targetContainer.style.visibility = "visible";

		// in case the currentHeight was set when the container was in display:none mode
		// we want to make sure that the correct height is stored
		var currentHeight = Sys.UI.DomElement.getBounds(this._targetContainer).height;
		//if (currentHeight > this._containerHeight) {
		this._containerHeight = currentHeight;
		//}

		// adds an iframe on the back of the dropdown container in order to handle the SELECT bug with IE 6
		this._addBackgroundIFrame();

		// we need to know what is the max height towards which the animation will grow the container
		this._dropDownAnimation.set_maxHeight(this._containerHeight);

		if (this._enableAnimations)
		{
			this._dropDownAnimation.play(); // start the 'show' animation

		}

	},

	__hideDropDown: function()
	{
		if (this._enableAnimations)
		{
			this._dropDownAnimation.play(); // start the 'hide' animation

		} else
		{
			// if animations are enabled the stuff below will be done in the end() animation method
			this._targetContainer.style.display = 'none';
			this._targetContainer.style.visibility = 'hidden';
			// hide the background iframe
			if (this._childFrame)
			{
				this._childFrame.style.display = "none";
			}

		}

	},

	__notifyAnimationEnd: function()
	{
		if (this._animationEndListener != null && this._animationEndListener._onAnimationEnd)
			this._animationEndListener._onAnimationEnd();
	}

	

};

$IG.DropDownBehavior.registerClass("Infragistics.Web.UI.DropDownBehavior");



$IG.UIObjectDropDownBehavior = function()
{
    ///<summary locid="T:J#Infragistics.Web.UI.UIObjectDropDownBehavior">
    /// An object that allows the developer to specify elements and/or UIObjects that 
    /// should be source elements and/or target elements.  the Target element wll be the 
    /// drop down target (popup) while the source will be the element that receives 
    /// drop down events
    ///</summary>
}

$IG.UIObjectDropDownBehavior.prototype = 
{

};

$IG.UIObjectDropDownBehavior.registerClass("Infragistics.Web.UI.UIObjectDropDownBehavior");


$IG.DropDownEvents = function (behavior) 
{

    ///<summary>
    /// An object that allows the developer to attach event listeners associated with a 
    /// Infragistics.Web.UI.DropDownBehavior. All handlers should have the following signature: 
    /// handler (behavior, evntArgs)
    ///</summary>
    this._handlers ={};
    this._behavior = behavior;
}

$IG.DropDownEvents.prototype = 
{
    addSetVisibleHandler:function(handler)
    {
		///<summary locid="M:J#Infragistics.Web.UI.UIObjectDropDownBehavior.addSetVisibleHandler">
		/// this event will be invoked after the dropdown container has been shown
		///</summary>
		///<param name="handler" type="Function">
		/// The function that should be called when the event is fired.
		///</param>
        this.__addHandler("SetVisible", handler, $IG.DropDownEventArgs);
    },
    
    addSetHiddenHandler:function(handler)
    {
        ///<summary locid="M:J#Infragistics.Web.UI.UIObjectDropDownBehavior.addSetHiddenHandler">
        /// this event will be invoked after the dropdown container has been hidden
        ///</summary>
        ///<param name="handler" type="Function">
        /// The function that should be called when the event is fired.
        ///</param>
        this.__addHandler("SetHidden", handler, $IG.DropDownEventArgs);
    },
    
    addSettingHiddenHandler:function(handler)
    {
        ///<summary locid="M:J#Infragistics.Web.UI.UIObjectDropDownBehavior.addSettingHiddenHandler">
        /// this event will be invoked before the dropdown is physically hidden on the screen
        ///</summary>
        ///<param name="handler" type="Function">
        /// The function that should be called when the event is fired.
        ///</param>
        this.__addHandler("SettingHidden", handler, $IG.CancelDropDownEventArgs);
    },
    
    addSettingVisibleHandler:function(handler)
    {
        ///<summary locid="M:J#Infragistics.Web.UI.UIObjectDropDownBehavior.addSettingVisibleHandler">
        /// this event will be invoked before the dropdown is physically shown on the screen
        ///</summary>
        ///<param name="handler" type="Function">
        /// The function that should be called when the event is fired.
        ///</param>
        this.__addHandler("SettingVisible", handler, $IG.CancelDropDownEventArgs);
    },
    
    removeSetVisibleHandler:function()
    {
        ///<summary locid="M:J#Infragistics.Web.UI.UIObjectDropDownBehavior.removeSetVisibleHandler">
        /// removes the handler
        ///</summary>
        ///<remarks>
        ///
        ///</remarks>
        this.__removeHandler("SetVisible");
    },
    
    removeSettingVisibleHandler:function()
    {
        ///<summary locid="M:J#Infragistics.Web.UI.UIObjectDropDownBehavior.removeSettingVisibleHandler">
        /// removes the handler
        ///</summary>
        ///<remarks>
        ///
        ///</remarks>
        this.__removeHandler("SettingVisible");
    },
    
    removeSetHiddenHandler:function()
    {
        ///<summary locid="M:J#Infragistics.Web.UI.UIObjectDropDownBehavior.removeSetHiddenHandler">
        /// 
        ///</summary>
        ///<remarks>
        ///
        ///</remarks>
        this.__removeHandler("SetHidden");
    },
    
    removeSettingHiddenHandler:function()
    {
        ///<summary locid="M:J#Infragistics.Web.UI.UIObjectDropDownBehavior.removeSettingHiddenHandler">
        /// 
        ///</summary>
        ///<remarks>
        ///
        ///</remarks>
        this.__removeHandler("SettingHidden");
    },
    
    // we keep a map of handlers that have been registered
    __addHandler:function(name, handler, args)
    {
		var handlers = this._handlers[name];
		if(!handlers)
			this._handlers[name] = handlers = [];
		
		var i = -1;
		while(++i < handlers.length)
			if(handlers[i])
				break;
		handlers[i] = [handler, args];
    },
    
    __removeHandler:function(name, handler, args)
    {
		var handlers = this._handlers[name];
		if(!handlers)
			return;
		var i = -1;
		while(++i < handlers.length)
		{
			var obj = handlers[i];
			if(obj && obj[0] == handler)
				handlers[i] = null;
		}
    },
    
    // fires an event using the registered handler for that event
    _fireEvent:function(name, evntArgs)
    {
		var handlers = this._handlers[name];
		var count = handlers ? handlers.length : 0;
		for(var i = 0; i < count; i++)
		{
			var handler = handlers[i];
			if(!handler)
				continue;
			var evnt = handler[0];
			var args = new handler[1](evntArgs);
			// if the cancel flag was set in the DropDown cancel event arguments
			// we will cancel this event
			evnt(this._behavior, args);
			if(args._cancel)
				return true; // will cancel
		}
		return false;
    }
}

$IG.DropDownEvents.registerClass("Infragistics.Web.UI.DropDownEvents");

$IG.DropDownEventArgs = function(behavior) 
{
    ///<summary locid="T:J#Infragistics.Web.UI.DropDownEventArgs">
    /// arguments class for dropdown events
    ///</summary>
    this._behavior = behavior;
}

$IG.DropDownEventArgs.prototype = 
{
    get_source: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DropDownEventArgs.source">
        /// returns the source DOM element
        ///</summary>
        ///<returns domElement="true">the source DOM element</returns>
        return this._behavior.get_sourceElement();
    },
    
    get_targetContainer: function()
    {
		///<summary locid="P:J#Infragistics.Web.UI.DropDownEventArgs.targetContainer">
		/// returns the target container DOM element
		///</summary>
		///<returns domElement="true">the target container DOM element</returns>
        return this._behavior.get_targetContainer();
    },
    
    get_targetContent: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DropDownEventArgs.targetContent">
        /// returns the target content DOM element (usually the first child of the target container)
        ///</summary>
        ///<returns domElement="true">the target content DOM element (usually the first child of the target container)</returns>
        return this._behavior.get_targetContent();
    },
    
    get_dropDownBehavior: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DropDownEventArgs.dropDownBehavior">
        /// returns a reference to the DropDownBehavior
        ///</summary>
		///<returns type="Infragistics.Web.UI.DropDownBehavior">a reference to the DropDownBehavior </returns>
        return this._behavior;
    }
    
}

$IG.DropDownEventArgs.registerClass("Infragistics.Web.UI.DropDownEventArgs");


$IG.CancelDropDownEventArgs = function (behavior) 
{
    this._cancel = false; // to cancel the event
    $IG.CancelDropDownEventArgs.initializeBase(this, [behavior]);
}

$IG.CancelDropDownEventArgs.prototype = 
{
    get_cancel: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DropDownEventArgs.cancel">
        /// whether event should be cancelled or not 
        ///</summary>
        ///<returns type="Boolean"> indicates if the -ed event will be cancelled or not </returns>
        return this._cancel;
    },
    
    set_cancel: function(cancel)
    {
        ///<summary locid="P:J#Infragistics.Web.UI.DropDownEventArgs.cancel">
        /// Cancels the firing of the next event in the chain, if set to true
        ///</summary>
        ///<remarks>
        ///
    	///</remarks>
        ///<param name="cancel" type="Boolean">value indicating if cancelling of the next event in the chain should occur</param>
        this._cancel = cancel;
    }
}

$IG.CancelDropDownEventArgs.registerClass("Infragistics.Web.UI.CancelDropDownEventArgs", $IG.DropDownEventArgs);


///------------- DROP DOWN ANIMATION ----------------------

$IG.DropDownAnimation = function(behavior)
{
    ///
    /// <summary>
    /// the drop down animation extends $IG.AnimationBase
    /// it is a very simple animation that manipulates the height of the animationContainer which is the parent of the target dropdown container
    /// in case the animation is performed from bottom to top, we also manipulate the marginTop property
    /// to create the effect that the container actually slides from bottom to top
    ///
    /// we change the animationContainer's height on every animation tick, in the onNext() method
    /// </summary>
    ///
    this._dropDownBehavior = behavior;
    this._increaseDelta = 0; // number of pixels by which we modify the height on every animation tick
    this._marginDelta=0;
    this._accumulatedHeight = 0; // currently accumulated height
    this._maxHeight = 0; // maximum height to which we will grow the container
    this._minHeight=0;
    this._maxMargin=0; // max margin if the animation is from bottom to top
    this._container = null;
    this._isTop = false;
    this._accumulatedMarginTop = 0; // if the animation is from bottom to top
    
    $IG.DropDownAnimation.initializeBase(this);
}

$IG.DropDownAnimation.prototype = 
{

    set_maxHeight:function(maxHeight) 
    {
		///<summary locid="P:J#Infragistics.Web.UI.DropDownEventArgs.maxHeight">
		/// sets the max height of the animating container
		///</summary>
		///<param name="maxHeight" type="Number" integer="true"></param>
        this._maxHeight = maxHeight;
    },

    onBegin:function() 
    {
		///<summary locid="M:J#Infragistics.Web.UI.DropDownEventArgs.onBegin">
		/// called before the animation begins 
		///</summary>

        this._container = this._dropDownBehavior.get_animationsContainer();
        
        var pos = this._dropDownBehavior.get_position();
        
        // calculate the number of pixels to increase the container height
        // we don't really need this if we use calc() from $IG.AnimationBase
        //this._increaseDelta = this._maxHeight / this.get_duration();
        
        if (this._dropDownBehavior.get_visible())
        {
            this._accumulatedHeight = this._maxHeight;
            // since the dropdown is already shown, and we will be performing an top to bottom 
            // animation, we will actually decrease the height of the container
            // this is not needed if we use calc() from $IG.AnimationBase
            this._increaseDelta = -1*this._increaseDelta;
        }

        if (this._dropDownBehavior.get_offScreen() || pos == $IG.DropDownPopupPosition.TopLeft || pos == $IG.DropDownPopupPosition.TopRight)
        {
            // in the case when the drop down container is positioned above the source element
            // we need to also change the marginTop to create the visually correct animation effect
            this._isTop = true;        
            this._marginDelta = this._increaseDelta;
            // we will grow the margin until it reaches the initial margin as if 
            // there was no animation taking place
            this._maxMargin = parseInt(this._container.style.marginTop); 

            // initial marginTop
            this._accumulatedMarginTop = this._maxMargin + this._maxHeight;
            
            if (this._dropDownBehavior.get_visible()) {
                // in case the dropdown is positioned above, and is already shown and the
                // animation will be from top to bottom (hiding)
                this._accumulatedMarginTop = this._maxMargin;
            }
            
            this._container.style.marginTop = this._accumulatedMarginTop + 'px';

           // this._accumulatedMarginTop = $util.getPosition(this._dropDownBehavior.get_sourceElement()).y;
            

            















            
            //this._container.style.marginTop = this._accumulatedMarginTop + 'px';
        }

    },
    
    onNext:function() 
    {
		///<summary locid="M:J#Infragistics.Web.UI.DropDownEventArgs.onNext">
		/// subsequently called while animation is in progress 
		///</summary>
    
       // modify the height
      // if (this._dropDownBehavior.get_Visible()) {
      //  this._increaseDelta = this._calc($IG.AnimationEquationType.EaseInOut, this._time, this._maxHeight, 0, this.get_duration());
       //} else {
        this._increaseDelta = this._calc(this._dropDownBehavior.get_animationType(), this._time, 0, this._maxHeight, this.get_duration());
      // }

      if (this._dropDownBehavior.get_visible()) {
       this._increaseDelta = -1*this._increaseDelta;
      } 
      
      this._accumulatedHeight += this._increaseDelta;
       
       // stop the animation if we have surpassed the maximum height we can grow to
       if (this._accumulatedHeight >= this._maxHeight || this._accumulatedHeight <0 ) {
       
           if (this._accumulatedHeight<0)
                this._accumulatedHeight=0; 
           else if (this._accumulatedHeight>this._maxHeight)
                this._accumulatedHeight=this._maxHeight; // the accumulated height should never grow above the maximum height

           this.stop(); // stop the current animation -> onEnd will be called after this function exits
           
       } 
       if (this._isTop)
       {    
            this._accumulatedMarginTop -= this._increaseDelta;
            this._container.style.marginTop = this._accumulatedMarginTop + 'px';
           
       }
       
        $util.setAbsoluteHeight(this._container, this._accumulatedHeight);
        
        // handle the background iFrame (IE6)
        if (this._dropDownBehavior._childFrame) {
            $util.setAbsoluteHeight(this._dropDownBehavior._childFrame, this._accumulatedHeight);
        }
    },
    
    onEnd:function() 
    {
		///<summary locid="M:J#Infragistics.Web.UI.DropDownEventArgs.onEnd">
		/// called when the animation ends 
		///</summary>

        if (this._isTop) {
            // if the dropdown container is positioned on the top and we are changing the margins as well
            // we need to make sure that the current accumulated margin top doesn't surpass or goes below
            // the maximum initial margin, after the animation ends
            if (this._accumulatedMarginTop != this._maxMargin)
            {
                this._container.style.marginTop = this._maxMargin + 'px';
            }
        }
        
        //re-initialize these variables for the next animation play
        this._accumulatedHeight=0;
        this._accumulatedMarginTop = 0;
        this._increaseDelta=0;
        this._marginDelta=0;
        this._isTop=false;

        // the dropdown was visible, now we need to hide the container because 
        // it is hidden now
        
        // we must not call set_Visible as it will actually want to cause the popup
        // to show and hide
        // we just flip the _visible property in the dropdown behavior
        
		var dd = this._dropDownBehavior, vis = dd.get_visible(), cont = this._container, iframe = dd._childFrame;
		dd._visible = !vis;
		if (vis)
		{
			
			if (cont)
			{
				cont.style.display = 'none';
				cont.style.visibility = 'hidden';
			}
			// hide the iframe
			if (iframe)
				iframe.style.display = "none";
		}
		// notify listener for animation end event
		this._dropDownBehavior.__notifyAnimationEnd();
	}
}

$IG.DropDownAnimation.registerClass("Infragistics.Web.UI.DropDownAnimation", $IG.AnimationBase);
