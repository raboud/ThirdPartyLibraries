/*
* igWebDataTreeNode.js
* Version 12.1.20121.2236
* Copyright(c) 2001-2013 Infragistics, Inc. All Rights Reserved.
*/



$IG.DataTreeNodeProps = new function()
{
    this.Expanded               = [$IG.NavItemProps.Count + 0, 0];
    this.NodeEdited             = [$IG.NavItemProps.Count + 1, 0];
    this.Selected               = [$IG.NavItemProps.Count + 2, 0];
    this.Editable               = [$IG.NavItemProps.Count + 3, 0];
    this.CssClass               = [$IG.NavItemProps.Count + 4, ""];
    this.SelectedCssClass       = [$IG.NavItemProps.Count + 5, ""];
    this.ActiveCssClass         = [$IG.NavItemProps.Count + 6, ""];
    this.HoverCssClass          = [$IG.NavItemProps.Count + 7, ""];
    this.DisabledCssClass       = [$IG.NavItemProps.Count + 8, ""];
    this.CheckState             = [$IG.NavItemProps.Count + 9, $IG.CheckBoxState.Unchecked];
    this.Clicked                = [$IG.NavItemProps.Count + 10, 0];
    this.Count                  = $IG.NavItemProps.Count  + 11;
};



$IG.Node = function(adr, element, props, owner, csm, collection, parent)
{
	///<summary locid="T:J#Infragistics.Web.UI.Node">
    /// The Node class is used to represent the object model of a node within the DataTree.
    ///</summary>
    $IG.Node.initializeBase(this, [adr, element, props, owner, csm, collection, parent]);
    this.__NodeAnimation = null;
	// M.H. 20 Dec. 2011 Fix for bug 96766
	this.__IsAJAXCallback = false;
    this._itemCollection._owner = this;
    if(!$util.isNullOrUndefined(this._get_owner()))
        this._stylePrefix = this._get_owner()._getStylePrefix();
}

$IG.Node.prototype =
{
    set_text: function(text) {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.text">
        /// Sets the text content of a node within the tree.
        ///</summary>
		/// <param name="text" type="String"/>
        $IG.Node.callBaseMethod(this, 'set_text', [text]);
        var textEl = this.get_textElement();
        if (textEl != null) {
            textEl.innerHTML = text;
        }
    },

    get_textElement: function() {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.textElement">
        /// Returns a reference to the Html Element that contains the text of the node.
        ///</summary>
		/// <returns domElement="true"></returns>
        return this.get_styleElement();
    },

    get_styleElement: function() {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.styleElement">
        /// Returns a reference to the Html Element that will be styled.
        ///</summary>
		/// <returns domElement="true"></returns>
        var styleEl = null;
        var nodeElement = this.get_element();
        if (nodeElement == null)
            return null;

        var child = nodeElement.firstChild;
        
        //A.T. WebExplorerBar
        if (child !=null && child.tagName == "DIV") styleEl = child;
       
        while (child != null) {
            
            if (child.tagName == "A") styleEl = child;
            else if (child.tagName == "TABLE") {
                //styleEl = child.firstChild.firstChild.firstChild;
                //break;
                var child2 = child.firstChild;
                while (child2) {
                    if (child2.tagName == "TBODY") {
                        var child3 = child2.firstChild;
                        while (child3) {
                            if (child3.tagName == "TR") {
                                var child4 = child3.firstChild;
                                while (child4) {
                                    if (child4.tagName == "TD") {
                                        return child4;
                                    }
                                    child4 = child4.nextSibling;
                                }
                            }
                            child3 = child3.nextSibling;
                        }
                    }
                    child2 = child2.nextSibling;
                }
            }
            child = child.nextSibling;
        }
        return styleEl;
    },

    _get_checkBoxElement: function() {
        ///<summary>
        /// Returns a reference to the image check box html element.
        ///</summary>
        var child = this.get_element().firstChild;
        while (child != null) {
            if (child.tagName == "IMG" && child.id.length > 0) 
            {
				
				$util._initAttr(child);
				if (child.getAttribute("mkr") == "check")
					return child;
			}
            child = child.nextSibling;
        }
        return null;
    },

    get_anchorElement: function() {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.anchorElement">
        /// Returns a reference to the Anchor Html Element associated with this node.
        ///</summary>
		/// <returns domElement="true"></returns>
        var anchorEl = this.get_styleElement();
        if (anchorEl != null && anchorEl.tagName == "A") return anchorEl;
        // A.T. fix for WebExplorerBar
        if (anchorEl == null)
			return;
			
        if(anchorEl.tagName!="A" && anchorEl.childNodes.length>0 && anchorEl.childNodes[anchorEl.childNodes.length-1].tagName=="A") return anchorEl.childNodes[anchorEl.childNodes.length-1];
        return null;
    },

    set_selected: function(value) {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.selected">
        /// Sets the node to be selected using the SelectedCssClass
        ///</summary>
		///<param name="value" type="Boolean"/>
        //this._getFlags().setSelected(value);
        if (!this.get_enabled()) return;
        var tree = this._get_owner();
        tree._selectNode(this, value, null);
    },

    set_enabled: function(value) {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.enabled">
        /// Sets this item's enabled state
        ///</summary>
		///<param name="value" type="Boolean"/>
        this._getFlags().setEnabled(value);
        var cssClass = this._get_owner()._disabledCssClassResolved(this);
        if (value)
            $util.removeCompoundClass(this.get_styleElement(), cssClass);
        else
            $util.addCompoundClass(this.get_styleElement(), cssClass);
    },

    get_editable: function() {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.editable">
        /// Gets this item's editable state. 0-will use the parent tree's node editing setting, 1-off, 2-on.
        ///</summary>
		///<value type="Number" integer="true" />
        return this._get_value($IG.DataTreeNodeProps.Editable);
    },

    set_editable: function(value) {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.editable">
        /// Sets this item's editable state. 0-will use the parent tree's node editing setting, 1-off, 2-on.
        ///</summary>
		///<param name="value" type="Number" integer="true" />
        return this._set_value($IG.DataTreeNodeProps.Editable, value);
    },

    _toggleClicked: function() {
        var oldState = this._get_value($IG.DataTreeNodeProps.Clicked, true);
        this._set_value($IG.DataTreeNodeProps.Clicked, !oldState);
    },

    get_cssClass: function() {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.cssClass">
        /// Returns the cssClass used for this node. 
        ///</summary>
		///<value type="String" />
        return this._get_value($IG.DataTreeNodeProps.CssClass);
    },

    get_selectedCssClass: function() {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.selectedCssClass">
        /// Returns the selectedCssClass used for this node.
        ///</summary>
		///<value type="String" />
        return this._get_value($IG.DataTreeNodeProps.SelectedCssClass);
    },

    get_activeCssClass: function() {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.activeCssClass">
        /// Returns the activeCssClass used for this node.
        ///</summary>
		///<value type="String" />
        return this._get_value($IG.DataTreeNodeProps.ActiveCssClass);
    },

    get_hoverCssClass: function() {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.hoverCssClass">
        /// Returns the hoverCssClass used for this node. 
        ///</summary>
		///<value type="String" />
        return this._get_value($IG.DataTreeNodeProps.HoverCssClass);
    },

    get_disabledCssClass: function() {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.disabledCssClass">
        /// Returns the disabledCssClass used for this node. 
        ///</summary>
		///<value type="String" />
        return this._get_value($IG.DataTreeNodeProps.DisabledCssClass);
    },

    get_navigateUrl: function() {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.navigateUrl">
        /// Returns the url associated with the Node object.  When the node is clicked, the Url will be activated.
        ///</summary>
		///<value type="String" />
        var a = this.get_anchorElement();
        if (a != null)
            return a.href;
        else
            return null;
    },

    set_navigateUrl: function(url) {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.navigateUrl">
        /// Set the URL associated with this node object.
        ///</summary>
		///<value type="String" />
        this._set_value($IG.NavItemProps.NavigateUrl, url);
        var a = this.get_anchorElement();
        if (!$util.isNullOrUndefined(a))
            a.href = url;
    },

    get_target: function() {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.target">
        /// Returns the target frame associated with the Node object.  The target is used in conjunction with the NavigateUrl property.
        /// The target identifies the Frame or IFrame within the page that has the same corresponding Name attribute as the Target property.
        ///</summary>
		///<value type="String" />
        var a = this.get_anchorElement();
        if (a != null)
            return a.target;
        else
            return null;
    },
    
    set_target: function(target) {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.target">
        /// Set the navigate URL associated target.
        ///</summary>
		///<param name="target" type="String">Specify valid url target.</param>
		this._set_value($IG.NavItemProps.Target, target);
        var a = this.get_anchorElement();
        if (a != null)
            a.target = target;
    },

    get_visible: function()
    {
	    ///<summary locid="P:J#Infragistics.Web.UI.Node.visible">
	    /// Returns true if all parent of this node are expanded and the node is visible.
	    ///</summary>
        ///<value type="Boolean"/>                    
        var res = $IG.Node.callBaseMethod(this, 'get_visible');
        if(res)
        {
            var parent = this.get_parentNode();
            while (parent) {
                if (!parent.get_expanded()) return false;
                parent = parent.get_parentNode();
            }
        }
       // return true;
        return res;
    },

	set_visible: function (value)
	{
		///<summary locid="P:J#Infragistics.Web.UI.Node.visible">
		/// Sets this node's visible state
		///</summary>
		///<param type="Boolean" name="value">Value indicating if the node should be visible or not</param>
		$IG.Node.callBaseMethod(this, 'set_visible', [value]);

		var tree = this._get_owner();

		var parent = this.get_parentNode();
		if (parent != null)
			tree._updateNodeExpanderImage(parent._element, null, null);
		else
		{
			var prev = this.get_previousVisibleNode();
			if (prev != null)
				tree._updateNodeExpanderImage(prev._element, null, null);

			var next = this.get_nextVisibleNode();
			if (next != null)
				tree._updateNodeExpanderImage(next._element, null, null);
		}
	},

    get_checkState: function() {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.checkState">
        /// Gets the current CheckBoxState of the Node.
		/// 0-Unchecked, 1-Checked, 2-Partial.
        ///</summary>
		///<value type="Number" integer="true" />
        return this._get_value($IG.DataTreeNodeProps.CheckState);
    },

    set_checkState: function(value) {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.checkState">
        /// Sets the current CheckBoxState of the Node.
		/// 0-Unchecked, 1-Checked, 2-Partial.
        ///</summary>
		///<param name="value" type="Number" integer="true" />
        if (this.get_checkState() == value) return;
        
        var tree = this._get_owner();
        tree._checkNode(this, value);
        var checkBox = this._get_checkBox();
        checkBox.set_state(value);
        
        this.get_element().setAttribute("checked", value);
        this._set_value($IG.DataTreeNodeProps.CheckState, value);
    },

    





    toggle: function(fireEvents) {
        ///<summary locid="M:J#Infragistics.Web.UI.Node.toggle">
        /// Changes the Expanded state of the node to the opposite value from what it is currently.  If the node is
        /// expanded, then it will be collapsed.  If the node is collapsed, it will be expanded.
        ///</summary>
		/// <param name="fireEvents" type="Boolean">Determines if client events should be fired.</param>
        if (this.get_expanded())
            this.set_expanded(false, fireEvents);
        else
            this.set_expanded(true, fireEvents);
    },

    get_expanded: function() {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.expanded">
        /// Returns a boolean value which indicates true if the node is currently expanded, false otherwise.
        ///</summary>
		///<value type="Boolean"/>
        var val = this._get_value($IG.DataTreeNodeProps.Expanded);
        return (val == 1) ? true : false;
    },

    set_expanded: function(value, fireEvents) {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.expanded">
        /// Sets the expanded state of the node to the passed in value.
        /// If the second boolean parameter is true, clientside events will be fired for the expansion or collapse.
        ///</summary>
		/// <param name="value" type="Boolean"></param>
        /// <param name="fireEvents" type="Boolean">Determines if client events should be fired.</param>
        var list = this._itemCollection._csm._transactionList._orderedList;
        delete list["Postback"];
        var currentValue = this._get_value($IG.DataTreeNodeProps.Expanded);
        if(value == currentValue) return; // Already in the indicated state so return
        
        var tree = this._get_owner();
		
		var groupAnimationFinishedHandler = arguments[2];
        if (value && this.get_isEmptyParent() && !this.get_populated()) {
            this._checkBox = null;
            
            tree._fireExpandEventsOnPopulate = fireEvents;
            tree._populateItem(this);
			// M.H. 20 Dec. 2011 Fix for bug 96766 - set value to true - Callback should be made
			this.__IsAJAXCallback = true;
            return;
        }
        var subgroup = this._get_subgroup();

        if($util.isNullOrUndefined(subgroup))
        {
            this._set_value($IG.DataTreeNodeProps.Expanded, value);
            return;
        }

        if (!this.hasChildren()) {
            this._set_value($IG.DataTreeNodeProps.Expanded, value);
            if (value) {
                if (subgroup) {
                    subgroup.style.display = "";
                    subgroup.style.height = "";
                }
                if (fireEvents) {
                    list["Postback"] = [this._address, $IG.DataTreeNodeProps.Expanded[0], 1];
                    tree._raiseClientEvent('NodeExpanded', 'DataTreeNode', null, null, this);
                }
            }
            else {
                if (subgroup) subgroup.style.display = "none";
                if (fireEvents) {
                    list["Postback"] = [this._address, $IG.DataTreeNodeProps.Expanded[0], 0];
                    tree._raiseClientEvent('NodeCollapsed', 'DataTreeNode', null, null, this);
                }
            }
            return
        }
        if (this.__NodeAnimation != null) return;
        var aType = tree.get_animationEquationType();
        
        var disableAnimation = tree.getClientEventPostBack("NodeClick") == 1 || tree.getClientEventPostBack("SelectionChanged") == 1; 
        var useAnimation = aType >= 1 && aType <= 5 && !disableAnimation;
        var expImage = this._get_expandCollapseElement();
        if (!value) {
            if (fireEvents) {
                var args = tree._raiseClientEvent('NodeCollapsing', 'DataTreeNode', null, null, this);
                if (args && args.get_cancel()) return;
            }
            if (tree.get_enableExpandImages() && expImage) {
                var idx = expImage.getAttribute("idx");
				// M.H. 29 Nov. 2011 Fix for bug 96809
				if (idx !== null && idx !== undefined) {
					idx--;
					expImage.src = tree._imageList[idx].src;

					if (tree.get_expandImageToolTip() != null && tree.get_expandImageToolTip() != "")
                    {
                        var tooltip = tree.get_expandImageToolTip().replace(/\{0\}/, this.get_text());
						expImage.title = expImage.alt = tooltip;
                    }

					expImage.setAttribute("idx", idx);
				}
            }
            if (useAnimation) {
            	this._collapseWithEffect(subgroup, fireEvents, groupAnimationFinishedHandler);
            }
            else {
                subgroup.style.display = "none";
				// M.H. 20 Dec. 2011 Fix for bug 96766
				// If Callback is made then we should set that default value for expanded state for this node is TRUE(expanded)
				if (this.__IsAJAXCallback && this._csm._items[this._address] && this._csm._items[this._address][0]) {
					this._csm._items[this._address][0][$IG.DataTreeNodeProps.Expanded[0]] = 1;
				}

                this._set_value($IG.DataTreeNodeProps.Expanded, value);
                if (fireEvents) {                    
                    list["Postback"] = [this._address, $IG.DataTreeNodeProps.Expanded[0], 0];
                    tree._raiseClientEvent('NodeCollapsed', 'DataTreeNode', null, null, this);
                }
            }
        }
        else {
            if (fireEvents) {
                var args = tree._raiseClientEvent('NodeExpanding', 'DataTreeNode', null, null, this);
                if (args && args.get_cancel()) return;
            }
            if (tree.get_enableExpandImages() && expImage) {
                var idx = expImage.getAttribute("idx");
                idx++;
                expImage.src = tree._imageList[idx].src;

                if (tree.get_collapseImageToolTip() != null && tree.get_collapseImageToolTip() != "")
                {
                    var tooltip = tree.get_collapseImageToolTip().replace(/\{0\}/, this.get_text());
                    expImage.title = expImage.alt = tooltip;
                }

                expImage.setAttribute("idx", idx);
            }
            if (useAnimation) {
            	this._expandWithEffect(subgroup, fireEvents, groupAnimationFinishedHandler);
            }
            else {
                subgroup.style.display = "";
                //subgroup.style.height = "";
                // A.T. 16 Feb. 2010 - MaxGroupHeight / GroupContentsHeight support for WebExplorerBar
                if (parseInt(subgroup.style.height) > 0 && this.get_level() == 0)
                {
					subgroup.style.overflowY='auto';
					subgroup.style.overflowX='hidden';
                } else
                {
					subgroup.style.height = "";
                }
                this._set_value($IG.DataTreeNodeProps.Expanded, value);
                if (fireEvents) {
                    list["Postback"] = [this._address, $IG.DataTreeNodeProps.Expanded[0], 1];
                    tree._raiseClientEvent('NodeExpanded', 'DataTreeNode', null, null, this);
                }
            }

            if(fireEvents &&
               tree.get_enableSingleBranchExpand() &&
               (tree.get_singleBranchExpandLevel() == -1 ||
                this.get_level() <= tree.get_singleBranchExpandLevel()))
            {
                this.collapseSiblings();
            }
        }
        if (!value) tree._ensureActiveVisible(this);
    },

	
    _expandWithEffect: function(e, fireEvent, groupAnimationFinishedHandler) {

        this.__NodeAnimation = new $IG.NodeAnimation(e, this._get_owner().get_animationEquationType(), true, this, fireEvent);
        this.__NodeAnimation.set_duration(this._get_owner().get_animationDuration());
		if (groupAnimationFinishedHandler)
			this.__NodeAnimation.addOnEndListener(groupAnimationFinishedHandler);
        this.__NodeAnimation.play();
    },

    _collapseWithEffect: function(e, fireEvent, groupAnimationFinishedHandler) {
        this.__NodeAnimation = new $IG.NodeAnimation(e, this._get_owner().get_animationEquationType(), false, this, fireEvent);
        this.__NodeAnimation.set_duration(this._get_owner().get_animationDuration());
		if (groupAnimationFinishedHandler)
			this.__NodeAnimation.addOnEndListener(groupAnimationFinishedHandler);
        this.__NodeAnimation.play();
    },

    _get_subgroup: function() {
        
        var last = this.get_element();
        if (last)
			last = last.lastChild;
        return (last && last.tagName == "UL") ? last : null;
    },

    _get_expandCollapseElement: function() {
        for (var i = 0; i < this._element.childNodes.length; i++) {
            var childNode = this._element.childNodes[i];
            

            if (childNode.attributes != null) {
                var idx = childNode.getAttribute("idx");
                if (idx)
                    return childNode;
				// M.H. 29 Nov. 2011 Fix for bug 96839
				// when there is connector lines first node could be blank image
//                if(childNode.tagName == "IMG")
//                    return childNode;

                var s = childNode.innerHTML;
                var t = s;
            }
        }
        //if(this._element._expImage)
        //    return this._element._expImage;

        return null;
    },
    
    get_level: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.level">
        /// Returns the current node level. 0 means root level element.
        ///</summary>
		///<returns type="int"/>
        return  $adrutil.getLevelByAdr($adrutil.getLocationFromDomElement(this.get_element()));
    },

    get_childNode: function(index) {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.childNode">
        /// Returns the child node at the index specified if it exists.  Null is returned otherwise.
        ///</summary>
		///<param name="index" type="Number" integer="true">Index of the node in the collection.</param>
		///<returns type="Infragistics.Web.UI.Node"/>
        return this.getItems().getNode(index);
    },

    hasChildren: function() {
        ///<summary locid="M:J#Infragistics.Web.UI.Node.hasChildren">
        /// Returns a boolean value which indicates whether or not this node has any child nodes beneath it.
        ///</summary>
		///<returns type="Boolean"/>
        var children = this.get_element().getElementsByTagName("LI");
        if (children.length > 0)
            return true;
        else
            return false;
    },

    get_childrenCount: function() {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.childrenCount">
        /// Returns the subnodes count.
        ///</summary>
        ///<value type="Number" integer="true" />
        var tree = this._get_owner();
        return tree._get_childrenCount(this._element);
    },

    get_parentNode: function() {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.parentNode">
        /// Returns the parend node of this node. 
        /// If this is a root node will return null.
        ///</summary>
		///<returns type="Infragistics.Web.UI.Node"/>
        var nodeElement = this.get_element();
		if(!$util.isNullOrUndefined(nodeElement))
		{
		    var parentEl = nodeElement.parentNode;
		    if(!$util.isNullOrUndefined(parentEl) &&
		       !$util.isNullOrUndefined(parentEl.parentNode) &&
		       parentEl.parentNode.nodeName == "LI")
		    {
		        return this._getUIBehavior().getItemFromElem(parentEl.parentNode);
		    }
		}
		return null;
    },

    get_nextNode: function() {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.nextNode">
        /// Returns the next sibling node of this node.
        /// If this is the last node in the collection, null is returned.
        ///</summary>
		///<returns type="Infragistics.Web.UI.Node"/>
        var nodeElement = this.get_element();
		if(!$util.isNullOrUndefined(nodeElement))
		{
		    var nextElement = $util.skipTextNodes(nodeElement.nextSibling);
		    if (!$util.isNullOrUndefined(nextElement))
		        return this._getUIBehavior().getItemFromElem(nextElement);
		}
		return null;
    },

	get_nextVisibleNode: function() {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.nextVisibleNode">
        /// Returns the next visible sibling node of this node.
        /// If this is the last visible node in the collection, null is returned.
        ///</summary>
		///<returns type="Infragistics.Web.UI.Node"/>
        var nextNode = this.get_nextNode();

		while (nextNode != null && !nextNode.get_visible())
			nextNode = nextNode.get_nextNode();

		return nextNode;
    },

    get_previousNode: function() {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.previousNode">
        /// Returns the previous sibling node of this node.
        /// If this is the first node in the collection, null is returned.
        ///</summary>
		///<returns type="Infragistics.Web.UI.Node"/>
		var nodeElement = this.get_element();
		if(!$util.isNullOrUndefined(nodeElement))
		{
		    var previousElement = $util.skipTextNodes(nodeElement.previousSibling, true);
		    if (!$util.isNullOrUndefined(previousElement))
		        return this._getUIBehavior().getItemFromElem(previousElement);
		}
		return null;
    },

    get_previousVisibleNode: function() {
        ///<summary locid="P:J#Infragistics.Web.UI.Node.previousVisibleNode">
        /// Returns the previous visible sibling node of this node.
        /// If this is the first visible node in the collection, null is returned.
        ///</summary>
		///<returns type="Infragistics.Web.UI.Node"/>
		var previousNode = this.get_previousNode();

		while (previousNode != null && !previousNode.get_visible())
			previousNode = previousNode.get_previousNode();

		return previousNode;
    },

    _ensureFlags: function() {
        $IG.Node.callBaseMethod(this, '_ensureFlags');
        this._ensureFlag($IG.ClientUIFlags.Selected, false);
        this._ensureFlag($IG.ClientUIFlags.Draggable, $IG.DefaultableBoolean.True);
		this._ensureFlag($IG.ClientUIFlags.Droppable, $IG.DefaultableBoolean.True);
    },

    _get_navigationUpNode: function() {
        var res = this.get_previousNode();
        while (res != null && res.hasChildren() && res.get_expanded()) {
            var lastIndex = res.get_childrenCount() - 1;
            res = res.get_childNode(lastIndex);
        }
        if (res == null) {
            res = this.get_parentNode();
        }
        return res;
    },

    _get_navigationDownNode: function() {
        var res = null;
        if (this.hasChildren() && this.get_expanded()) {
            res = this.get_childNode(0);
        }
        if (res == null) {
            var parent = this;
            while (parent != null) {
                res = parent.get_nextNode();
                if (res != null) break;
                parent = parent.get_parentNode();
            }
        }
        return res;
    },

    isAfter: function(node) 
	{
		///<summary locid="M:J#Infragistics.Web.UI.Node.isAfter">Checks if this node instance is after the passed as a parameter node.</summary>
		///<param name="node" type="Infragistics.Web.UI.Node"/>
		///<value type="Boolean"/>
		if($util.isNullOrUndefined(node))
		    return false;

        var currentNodeElement = this.get_element();
        var nodeElement = node.get_element();
        if ($util.IsIE6 || $util.IsIE7 || $util.IsIE8)
        {
            return currentNodeElement.sourceIndex - nodeElement.sourceIndex > 0;
        }
        else
        {
            if (nodeElement.compareDocumentPosition)
            {
                // if currentNodeElement follows (4) and is contained by (16) nodeElement, the method returns 20.
                // convert it to bool ! and then again ! to return the correct bool value.
                return !!(nodeElement.compareDocumentPosition(currentNodeElement) & 20);
            }
        }
    },

    _get_checkBox: function() {
        if (this._checkBox == null) {
            var element = this._get_checkBoxElement();

            var props = new Array();
            var clientProps = new Array();
            var length = $IG.ImageCheckBoxProps.Count;
            for (var i = 0; i < length; i++)
                clientProps.push(null);
            props.push(clientProps);
            var csm = new $IG.ObjectClientStateManager(props);
            this._checkBox = new $IG.ImageCheckBox(this._address + ".chk", element, props, this, csm);
            var tree = this._get_owner();
            this._checkBox.set_uncheckedImageURL(tree._uncheckedImageURL);
            this._checkBox.set_checkedImageURL(tree._checkedImageURL);
            this._checkBox.set_partialImageURL(tree._partialImageURL);
            this._checkBox.set_state(this.get_checkState());
        }
        return this._checkBox;
    },

    collapseSiblings: function() {
        ///<summary locid="M:J#Infragistics.Web.UI.Node.collapseSiblings">
        /// This will collapse all sibling nodes. If they are currently animating expanded,
        /// the animation is stopped and reversed.
        ///</summary>
        var firstSiblingElement = $util.skipTextNodes(this.get_element().parentNode.firstChild);
        var sibling = this._getUIBehavior().getItemFromElem(firstSiblingElement);
        while (sibling != null) {
            if (sibling != this) {
                if (sibling.__NodeAnimation != null && sibling.__NodeAnimation.isExpanding) {
                    sibling.__NodeAnimation.stop();
                    sibling.__NodeAnimation = null;
                    sibling._set_value($IG.DataTreeNodeProps.Expanded, true);
                }
                sibling.set_expanded(false);
            }
            sibling = sibling.get_nextNode();
        }
    },
    
    dispose: function()
    {
        ///<summary locid="M:J#Infragistics.Web.UI.Node.dispose">Disposes the object and all of its children.</summary>
        if(this.__NodeAnimation && this.__NodeAnimation.get_isAnimating())
        {
            this.__NodeAnimation.stop();
        }
        this.__NodeAnimation = null;
        $IG.Node.callBaseMethod(this, "dispose");
    },

    remove: function(keepChildren)
    {
        ///<summary locid="M:J#Infragistics.Web.UI.Node.remove">Removes the node from the parent node nodes collection</summary>
        ///<param name="keepChildren" type="Boolean">If true the children will not be removed.</param>
        ///<returns type="Boolean">Returns true if the node is successfully removed.</returns>
        var parent = this.get_parentNode();
        
        if(!$util.isNullOrUndefined(parent))
        {
            return parent.getItems().remove(this, keepChildren);
        }
        else
        {
            return this._get_owner().remove(this, keepChildren);
        }
    },

    _navigateOnClick: function()
    {
        var url = this.get_navigateUrl();
        // K.D. May 17, 2011 Bug 75087 We have to check whether the last symbol in the URL is not '#'
        if(this.get_enabled() && url != null && url != '' && url.lastIndexOf('#') + 1 !== url.length)
        {
            var targetFrame = this.get_target();

            if(targetFrame == null || targetFrame == "")
                targetFrame = "_self";

            window.open(url,targetFrame);
        }
    },

    _getUIBehavior: function()
    {
        if($util.isNullOrUndefined(this._controlUIBehavior))
        {
            this._controlUIBehavior = this._get_owner()._itemCollection._getUIBehaviorsObj();
        }
        return this._controlUIBehavior;
    }
}
$IG.Node.registerClass('Infragistics.Web.UI.Node', $IG.NavItem);



$IG.NodeAnimation = function(element, type, isExpanding, node, fe)
{
    this.element = element;
    this.animEqType = $IG.AnimationEquationType.Linear;
    if (type == 2) this.animEqType = $IG.AnimationEquationType.EaseIn;
    else if (type == 3) this.animEqType = $IG.AnimationEquationType.EaseOut;
    else if (type == 4) this.animEqType = $IG.AnimationEquationType.EaseInOut;
    else if (type == 5) this.animEqType = $IG.AnimationEquationType.Bounce;
    this.currentHeight = 0;
    this.isExpanding = isExpanding;
    this.node = node;
    this.fireEvent = fe;
    $IG.NodeAnimation.initializeBase(this);
    maxHeightSet=false;
}

$IG.NodeAnimation.prototype = 
{
    stop: function()
    {
        $IG.NodeAnimation.callBaseMethod(this, 'stop');
        this.onEnd();
    },

    onBegin: function() 
    {
        this.node._get_owner()._registerAnimationObject(this);

        this.element.style.overflow = "hidden";

        //A.T. WebExplorerBar MaxGroupHeight
        if (parseInt(this.element.style.height) > 0 && this.node.get_level() == 0)
        {
			this.maxHeight = parseInt(this.element.style.height);
			this.maxHeightSet=true;
			this.element.style.overflowY='hidden';
			
		}
		
        if (this.isExpanding)
        {
            this.initialHeight = 0;
            this.element.style.height = "0px";
            this.element.style.display = "";
        }
        else
        {
			if (this.maxHeightSet)
			{
				this.initialHeight = this.maxHeight;
			} else
			{
				this.initialHeight = this.element.scrollHeight;
            }
        }
        //A.T. WebExplorerBar MaxGroupHeight
        if (!this.maxHeightSet)
        {
			this.maxHeight = this.element.scrollHeight;
        }
    },

    onNext: function() 
    {
        var newValue = this._calc(this.animEqType, this._time, 0, this.maxHeight, this.get_duration());
        if (newValue >= this.maxHeight)
        {
            this.stop();
        }
        else
        {
            var newHeight = 0;
            if (this.isExpanding) newHeight = this.initialHeight + newValue;
            else newHeight = this.initialHeight - newValue;
            this.element.style.height = newHeight + "px";
        }
    },
    
    onEnd: function() 
    {
        if(this.endCalled)
            return;
        this.endCalled = true;

        this.element.style.overflow = "";

        var list = this.node._itemCollection._csm._transactionList._orderedList;
        delete list["Postback"];

        if (this.isExpanding)
        {
			if (!this.maxHeightSet)
			{
				this.element.style.height = "";
            }
            else
            {
				this.element.style.overflowY='auto';
				this.element.style.overflowX='hidden';
				this.element.style.height = this.maxHeight + 'px';
            }
            
            this.node._set_value($IG.DataTreeNodeProps.Expanded, true);
        }
        else
        {
			//if (this.maxHeightSet)
			//{
				this.element.style.height = "";
			//}
            this.element.style.display = "none";
            this.node._set_value($IG.DataTreeNodeProps.Expanded, false);
            
            this.node._get_owner()._ensureActiveVisible(this.node)
            
            if (this.maxHeightSet)
            {
				this.element.style.height = this.maxHeight + 'px';
            }
        }
        if (this.fireEvent)
        {
            if (this.isExpanding) {
                list["Postback"] = [this.node._address, $IG.DataTreeNodeProps.Expanded[0], 1];
                this.node._get_owner()._raiseClientEvent('NodeExpanded', 'DataTreeNode', null, null, this.node);
            }
            else {
                list["Postback"] = [this.node._address, $IG.DataTreeNodeProps.Expanded[0], 0];
                this.node._get_owner()._raiseClientEvent('NodeCollapsed', 'DataTreeNode', null, null, this.node);
            }
        }
		
		if (this._notifyHandlers && this._notifyHandlers.length)
		{
			for (var x = 0; x < this._notifyHandlers.length; ++x)
				this._notifyHandlers[x]();
		}
        this.maxHeightSet=false;
        this.node._get_owner()._unregisterAnimationObject(this);
        this.node.__NodeAnimation = null;
    },

	addOnEndListener: function (listener)
	{
		if (!this._notifyHandlers)
			this._notifyHandlers = [];
		this._notifyHandlers.push(listener);
	}

}
$IG.NodeAnimation.registerClass("Infragistics.Web.UI.NodeAnimation",$IG.AnimationBase);
