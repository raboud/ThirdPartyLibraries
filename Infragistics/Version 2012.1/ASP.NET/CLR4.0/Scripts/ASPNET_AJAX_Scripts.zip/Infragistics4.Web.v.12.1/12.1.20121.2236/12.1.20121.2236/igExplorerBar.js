/*
* igExplorerBar.js
* Version 12.1.20121.2236
* Copyright(c) 2001-2013 Infragistics, Inc. All Rights Reserved.
*/


Type.registerNamespace('Infragistics.Web.UI');


$IG.WebExplorerBarProps = new function()
{
    this.GroupExpandBehavior = [$IG.ControlMainProps.Count + 1, 1];
    this.GroupExpandAction = [$IG.ControlMainProps.Count + 2, 1];
    this.EnableExpandButtons = [$IG.ControlMainProps.Count + 3, true];
    this.MaxGroupHeight = [$IG.ControlMainProps.Count + 4, 0];
    // K.D. June 7th, 2011 Bug #78008 Introducing a new prop for the single expand expanded group
    this.SingleExpandExpanded = [$IG.ControlMainProps.Count + 5, 0];
    this.Count = $IG.ControlMainProps.Count + 6;
};

$IG.ExplorerBarGroupExpandBehavior = new function()
{
    /// <summary>Defines the types of expand behavior for the group objects.</summary> 
    /// <field name="SingleExpanded" type="Number" integer="true" static="true">This mode means that only one group can be expanded at a time.</field> 
    /// <field name="AnyExpandable" type="Number" integer="true" static="true">This mode means the any group can be expanded or collapsed.</field> 
    /// <field name="AllExpanded" type="Number" integer="true" static="true">This mode means that all groups will be expanded and they can not be collapsed.</field>
    this.SingleExpanded = 0;
    this.AnyExpandable = 1;
    this.AllExpanded = 2;
}

$IG.ExplorerBarGroupExpandAction = new function()
{
    /// <summary>Defines the types of expand actions the user needs to do in order to expand a group object.</summary> 
    /// <field name="ButtonClick" type="Number" integer="true" static="true">The group will expand only when the expander button is clicked.</field> 
    /// <field name="HeaderClick" type="Number" integer="true" static="true">The group will expand when clicked anywhere over the group header.</field> 
    /// <field name="HeaderHover" type="Number" integer="true" static="true">The group will expand when the mouse is over it.</field>
    this.ButtonClick = 0;
    this.HeaderClick = 1;
    this.HeaderHover = 2;
}

$IG.WebExplorerBar = function(element)
{
    /// <summary locid="T:J#Infragistics.Web.UI.WebExplorerBar">
    /// Allows the ability to hide/show data. 
    /// </summary>
    $IG.WebExplorerBar.initializeBase(this, [element]);

	$IG.WebExplorerBar.find = $find;
	$IG.WebExplorerBar.from = $IG._from;	
}

$IG.WebExplorerBar.prototype =
{
    _thisType: 'WebExplorerBar',
    _lastExpandedXM: null,
    _imageList: null,
    _iCollection: $IG.ExplorerBarItemCollection,
    _tree: $IG.WebDataTree,
    _dtID: '',
    _lastBrowserEvent: null,
    __bypassEventCheck: false,
    __hoverExpanderImage: false,
    __expandedImgTitle: '',
    __collapsedImgTitle: '',
    __collapsedImgAlt: '',
    __expandedImgAlt: '',
    
    initialize: function()
    {
        ///<summary locid="M:J#Infragistics.Web.UI.WebExplorerBar.initialize">Initializes the WebExplorerBar object.</summary>
        $IG.WebExplorerBar.callBaseMethod(this, 'initialize');
        this.__initInternalTree();
        this._raiseClientEvent('Initialize');
        /// customize tree collapse expand behavior when items are disabled.
        //this._tree._disableNodeCollapseExpand = true;
        this._tree._navigateOnAreaClick = true;
    },

    __initInternalTree: function()
    {
        
        this._dtID = this._get_clientOnlyValue("dtID");

        
        var fnExp = new Function('dt', 'e', "ig_controls." + this.get_id() + ".__nExpanding(dt,e)");
        var fnColl = new Function('dt', 'e', "ig_controls." + this.get_id() + ".__nCollapsing(dt,e)");
        var fnHov = new Function('dt', 'e', "ig_controls." + this.get_id() + ".__nHovered(dt,e)");
        var fnClick = new Function('dt', 'e', "ig_controls." + this.get_id() + ".__treeFinalEvents(dt,e,'click')");
        var fnExpanded = new Function('dt', 'e', "ig_controls." + this.get_id() + ".__nItemExpanded(dt,e)");
        var fnCollapsed = new Function('dt', 'e', "ig_controls." + this.get_id() + ".__nItemCollapsed(dt,e)");
        var fnUnhovered = new Function('dt', 'e', "ig_controls." + this.get_id() + ".__treeFinalEvents(dt,e,'unhovered')");
        var fnSelected = new Function('dt', 'e', "ig_controls." + this.get_id() + ".__treeFinalEvents(dt,e,'selected')");
        var fnSelecting = new Function('dt', 'e', "ig_controls." + this.get_id() + ".__treeFinalEvents(dt,e,'selecting')");
        var fnPopulated = new Function('dt', 'e', "ig_controls." + this.get_id() + ".__treeFinalEvents(dt,e,'populated')");
        var fnPopulating = new Function('dt', 'e', "ig_controls." + this.get_id() + ".__treeFinalEvents(dt,e,'populating')");
        var fnKeyDown = new Function('dt', 'e', "ig_controls." + this.get_id() + ".__nKeyDown(dt,e)");
        var fnMouseDown = Function.createDelegate(this, this.__onMouseDownHandler);

        var mouseOverDelegate = Function.createDelegate(this, this.__onMouseOverHandler);
        var mouseOutDelegate = Function.createDelegate(this, this.__onMouseOutHandler);

        




        this._tree = ig_controls[this._dtID];
        this._tree._web = true;
        this._tree.get_events().addHandler("NodeExpanding", fnExp);
        this._tree.get_events().addHandler("NodeCollapsing", fnColl);
        this._tree.get_events().addHandler("NodeHovered", fnHov);
        this._tree.get_events().addHandler("NodeExpanded", fnExpanded);
        this._tree.get_events().addHandler("NodeCollapsed", fnCollapsed);
        this._tree.get_events().addHandler("KeyDown", fnKeyDown);

        if (this.get_events().getHandler("ItemClick") != null && typeof (this.get_events().getHandler("ItemClick")) != "undefined")
            this._tree.get_events().addHandler("NodeClick", fnClick);
        if (this.get_events().getHandler("ItemUnhovered") != null && typeof (this.get_events().getHandler("ItemUnhovered")) != "undefined")
            this._tree.get_events().addHandler("NodeUnhovered", fnUnhovered);
        if (this.get_events().getHandler("ItemPopulating") != null && typeof (this.get_events().getHandler("ItemPopulating")) != "undefined")
            this._tree.get_events().addHandler("NodePopulating", fnPopulating);
        if (this.get_events().getHandler("ItemPopulated") != null && typeof (this.get_events().getHandler("ItemPopulated")) != "undefined")
            this._tree.get_events().addHandler("NodePopulated", fnPopulated);
        if (this.get_events().getHandler("ItemSelecting") != null && typeof (this.get_events().getHandler("ItemSelecting")) != "undefined")
            this._tree.get_events().addHandler("SelectionChanging", fnSelecting);
        if (this.get_events().getHandler("ItemSelected") != null && typeof (this.get_events().getHandler("ItemSelected")) != "undefined")
            this._tree.get_events().addHandler("SelectionChanged", fnSelected);

        // For Firefox, Opera, Chorme, Safari, IE9 we should fire on the capturing phase for a normal WebExplorerBar
        try 
		{
        	this._tree.get_element().addEventListener('mousedown', fnMouseDown, true);
        }
        catch (err) 
		{
        	//For bug #103831 and IE6,7 and 8, only this code works fine without exceptions
        	$addHandler(this._tree.get_element(), 'mousedown', fnMouseDown);
        }

        $addHandler(this._tree.get_element(), 'mouseover', mouseOverDelegate);
        $addHandler(this._tree.get_element(), 'mouseout', mouseOutDelegate);

        




        if (this.get_groupExpandBehavior() == $IG.ExplorerBarGroupExpandBehavior.SingleExpanded)
        {
            var firstLoadStr = this._get_clientOnlyValue("exp1stGrpInSE");
            var isFirstLoad = false;
            if(!$util.isNullOrUndefined(firstLoadStr))
            {
                isFirstLoad = Boolean.parse(firstLoadStr);
            }

            if(isFirstLoad)
            {
                // K.D. June 7th, 2011 Bug #78008 The expanded index handles group that is expanded initially.
                // Previously it was handled as the first group being expanded regardless of what is set in 
                // code behind. However now it is handled to set the expanded group correctly.
                var expandedIndex = this.get_singleExpandExpanded();
                var node = ig_controls[this._dtID].getNode(expandedIndex);
                if (!$util.isNullOrUndefined(node))
                {
                    if(this.get_groupExpandAction() == $IG.ExplorerBarGroupExpandAction.ButtonClick && !$util.TouchEnabled)
                    {
                        this.__bypassEventCheck = true;
                    }
                    node.toggle(true);
                    this.__currentExpandedRootNode = node;
                }
            }
            else
            {
                var expandedGroupAdr = this._get_clientOnlyValue("expGrpAddrInSE");
                if(!$util.isNullOrUndefined(expandedGroupAdr))
                {
                    this.__currentExpandedRootNode =
                        this.getExplorerBarItems()._nodeCollection._getObjectByAdr(expandedGroupAdr);
                }
            }
        }

        this.__initExpanderToolTips();
        // K.D. May 5th, 2011 Bug #74549 Calling this function in order to put dimensions on the WEB element if width
        // or height are in percentage instead of having them on the tree element
        this.__initDimensions();
    },

    __initDimensions: function()
    {
        // K.D. May 5th, 2011 Bug #74549 If width or height of the tree is set in percentages then the dimension
        // should be moved to the WEB element from the tree element
        var tree = this._tree._element;
        if(tree && tree.style.height && tree.style.height[tree.style.height.length - 1] == '%')
        {
            this._element.style.height = tree.style.height;
            tree.style.height = "";
        }
        if(tree && tree.style.width && tree.style.width[tree.style.width.length - 1] == '%')
        {
            this._element.style.width = tree.style.width;
            tree.style.width = "";
        }
    },
    
    __initExpanderToolTips: function()
    {
        var expImgTitle = this._get_clientOnlyValue("expToolTip");
        var clpImgTitle = this._get_clientOnlyValue("clpToolTip");
        var expImgAlt = this._get_clientOnlyValue("expImgAlt");
        var clpImgAlt = this._get_clientOnlyValue("clpImgAlt");
        
        if(!$util.isNullOrUndefined(expImgTitle))
        {
            this.__expandedImgTitle = expImgTitle;
        }

        if(!$util.isNullOrUndefined(clpImgTitle))
        {
            this.__collapsedImgTitle = clpImgTitle;
        }

        if(!$util.isNullOrUndefined(expImgAlt))
        {
            this.__expandedImgAlt = expImgAlt;
        }

        if(!$util.isNullOrUndefined(clpImgAlt))
        {
            this.__collapsedImgAlt = clpImgAlt;
        }
    },

    __onMouseDownHandler: function(browserEvent)
    {
        this._lastBrowserEvent = browserEvent;
    },

    __getTarget: function(browserEvent)
    {
        var target = browserEvent.target;
        if (!target)
            target = browserEvent.srcElement;
        return target;
    },

    __isTargetExpanderImage: function(browserEvent)
    {
        var target = this.__getTarget(browserEvent);

        if (target &&
           target.nodeName == "IMG" &&
           (target.id.indexOf("exp") != -1 ||
            target.id.indexOf("clp") != -1))
        {
            if (target.parentNode &&
               target.parentNode.nodeName == "DIV" &&
               target.parentNode.parentNode &&
               target.parentNode.parentNode.nodeName == "LI" &&
               target.parentNode.parentNode.getAttribute("adr"))
            {
                var itemElement = target.parentNode.parentNode;
                var node = this.getExplorerBarItems()._nodeCollection._getObjectByAdr(itemElement.getAttribute("adr"));
                return node;
            }
        }
    },

    __onMouseOverHandler: function(browserEvent)
    {
        var node = this.__isTargetExpanderImage(browserEvent);
        if (node && node.get_enabled())
        {
            this.__handleImageHover(node);
        }
        // if the mouse is moved, reset the flag.
        this.__hoverExpanderImage = false;
    },

    __onMouseOutHandler: function(browserEvent)
    {
        var node = this.__isTargetExpanderImage(browserEvent);
        if (node && node.get_enabled())
        {
            this.__handleExpandCollapse(node);
        }
        // if the mouse is moved, reset the flag.
        this.__hoverExpanderImage = false;
    },

    





































    
    
    __dtInit: function(dt, e)
    {
        dt.getNode(0).toggle(false);
        this._lastExpandedXM = dt.getNode(0);
    },

    __get_groupExpanderImage: function(node)
    {
        var divElem = node.get_element().childNodes[0];
        if(!$util.isNullOrUndefined(divElem))
        {
            var imageElem = divElem.childNodes[0];
            if(!$util.isNullOrUndefined(imageElem) &&
               imageElem.nodeName == "IMG" &&
               (imageElem.id.indexOf("exp") != -1 ||
                imageElem.id.indexOf("clp") != -1))
            {
                return imageElem;
            }
        }
        return null;
    },

    __get_ExpandImageUrl: function()
    {
        return this._get_clientOnlyValue("expandImg");
    },

    __get_ExpandHoverImageUrl: function()
    {
        return this._get_clientOnlyValue("expandHoverImg");
    },

    __get_CollapsedImageUrl: function()
    {
        return this._get_clientOnlyValue("collapseImg");
    },

    __get_CollapsedHoverImageUrl: function()
    {
        return this._get_clientOnlyValue("collapseHoverImg");
    },

    __handleExpandCollapse: function(node)
    {
        var expImage = this.__get_groupExpanderImage(node);
        if (expImage != null)
        {
            if (node.get_expanded())
            {
                expImage.src = this.__get_CollapsedImageUrl();
                expImage.id = expImage.id.replace("exp", "clp");
                expImage.title = this.__collapsedImgTitle;
                expImage.alt = this.__collapsedImgAlt;
            }
            else
            {
                expImage.src = this.__get_ExpandImageUrl();
                expImage.id = expImage.id.replace("clp", "exp");
                expImage.title = this.__expandedImgTitle;
                expImage.alt = this.__expandedImgAlt;
            }
        }
    },

    __handleImageHover: function(node)
    {
        var expImage = this.__get_groupExpanderImage(node);
        if (expImage != null)
        {
            if (node.get_expanded())
            {
                expImage.src = this.__get_CollapsedHoverImageUrl();
                expImage.id = expImage.id.replace("exp", "clp");
            }
            else
            {
                expImage.src = this.__get_ExpandHoverImageUrl();
                expImage.id = expImage.id.replace("clp", "exp");
            }
        }
    },

    __treeFinalEvents: function(dt, e, evtType)
    {
        var node = null;
        
        if (typeof (e.getNode) != "undefined")
            node = e.getNode();
        switch (evtType)
        {
            case "click":
                var args = this._raiseClientEvent('ItemClick', 'ExplorerBar', this._lastBrowserEvent, null, new $IG.ExplorerBarItem(this, node));
				if (args.get_cancel) {
					// L.T. 2-FEB-2011 63918 Allow the customers to cancel the event with a workaround! By design this event is not cancellable!
					e._cancel = args.get_cancel();
				}
                this._lastBrowserEvent = null;
                break;            
            case "unhovered":
                this._raiseClientEvent('ItemUnhovered', 'ExplorerBar', this._lastBrowserEvent, null, new $IG.ExplorerBarItem(this, node));
                break;
            case "selecting":
                var oldNode = null;
                var newNode = null;
                if (e.getOldSelectedNodes().length > 0)
                {
                    oldNode = e.getOldSelectedNodes()[0];
                }
                if (e.getNewSelectedNodes().length > 0)
                {
                    newNode = e.getNewSelectedNodes()[0];
                }
                var args = this._raiseClientEvent('ItemSelecting',
                                                  'ExplorerBarItemSelected',
                                                  this._lastBrowserEvent,
                                                  null,
                                                  ((!$util.isNullOrUndefined(oldNode)) ? new $IG.ExplorerBarItem(this, oldNode) : null),
                                                  ((!$util.isNullOrUndefined(newNode)) ? new $IG.ExplorerBarItem(this, newNode) : null));
                if (args && args.get_cancel())
                {
                    e.set_cancel(true);
                }
                break;
            case "selected":
                var oldNode = null;
                var newNode = null;
                if (e.getOldSelectedNodes().length > 0)
                {
                    oldNode = e.getOldSelectedNodes()[0];
                }
                if (e.getNewSelectedNodes().length > 0)
                {
                    newNode = e.getNewSelectedNodes()[0];
                }
                this._raiseClientEvent('ItemSelected',
                                       'ExplorerBarItemSelected',
                                       this._lastBrowserEvent,
                                       null,
                                       ((!$util.isNullOrUndefined(oldNode)) ? new $IG.ExplorerBarItem(this, oldNode) : null),
                                       ((!$util.isNullOrUndefined(newNode)) ? new $IG.ExplorerBarItem(this, newNode) : null));
                break;
            case "populating":
                var args = this._raiseClientEvent('ItemPopulating', 'ExplorerBarCancel', this._lastBrowserEvent, null, new $IG.ExplorerBarItem(this, node));
                if (args && args.get_cancel())
                {
                    e.set_cancel(true);
                }
                break;
            case "populated":
                this._raiseClientEvent('ItemPopulated', 'ExplorerBar', this._lastBrowserEvent, null, new $IG.ExplorerBarItem(this, node));
                this._lastBrowserEvent = null;
                break;
        }
    },

    __nCollapsing: function(dt, e)
    {
        var node = e.getNode();

        var isExpanderImageClicked = false;
        var raiseClientEvent = false;
        var nonRootNodeEvent = false;
        var behaveMode = this.get_groupExpandBehavior();
        var expandMode = this.get_groupExpandAction();
		if (expandMode == $IG.ExplorerBarGroupExpandAction.ButtonClick && $util.TouchEnabled)
			expandMode = $IG.ExplorerBarGroupExpandAction.HeaderClick;
        if (node._get_address().indexOf(".") > 0)
        {
            raiseClientEvent = true;
            nonRootNodeEvent = true;
        }

        var evt = this._lastBrowserEvent;
        if (evt != null && evt.target.id.indexOf("clp") != -1 ||
           this.__bypassEventCheck)
        {
            
            isExpanderImageClicked = true;

            if(!this.__bypassEventCheck)
                this.__hoverExpanderImage = true;
        }
        if (
             (expandMode == $IG.ExplorerBarGroupExpandAction.ButtonClick &&
                !isExpanderImageClicked &&
                !nonRootNodeEvent)
             ||
             (behaveMode == $IG.ExplorerBarGroupExpandBehavior.SingleExpanded &&
               node.get_expanded() &&
               !nonRootNodeEvent &&
               !this.__bypassEventCheck)
             ||
             (behaveMode == $IG.ExplorerBarGroupExpandBehavior.AllExpanded &&
               !nonRootNodeEvent)
             || (!node.get_enabled())
           )
        {
            e.set_cancel(true);
            this._lastBrowserEvent = null;
            return;
        }
        else
        {
            raiseClientEvent = true;
        }

        if (raiseClientEvent)
        {
            var args = this._raiseClientEvent('ItemCollapsing', 'ExplorerBarCancel', this._lastBrowserEvent, null, new $IG.ExplorerBarItem(this, node));
            if (args && args.get_cancel())
            {
                e.set_cancel(true);
                return;
            }
        }

        if (this.__bypassEventCheck)
            this.__bypassEventCheck = false;
    },

    









    __handleMaxGroupHeight: function(node, isExpanding)
    {
        // If MaxGroupHeight is turned on.
        if (this.get_maxGroupHeight() != 0)
        {
            var groupNode = node;
            // When a child is expanding find the parent
            // group node to apply to him the MaxGroupHeight,
            // not to the child node that is expanding now.
            while(groupNode != null && groupNode._get_address().indexOf(".") > 0)
            {
                groupNode = groupNode.get_parentNode();
            }

            if(groupNode != null)
            {
                var list = groupNode.get_element().getElementsByTagName("UL");
                var groupElem = list[0];

                if(groupElem != null && groupElem != 'undefined')
                {
                    // Show the group contents to be able to get actual offsetHeight
                    if(isExpanding)
                    {
                        groupElem.style.display = '';
                    }

                    // If child node is expanded, then aggregate
                    // group offsetHeight with child node offsetHeight,
                    // so that actual offsetHeight is greater than get_maxGroupHeight
                    var offsetHeight = Sys.UI.DomElement.getBounds(groupElem).height;
                    if(node != groupNode && isExpanding)
                    {
                        var nodeList = node.get_element().getElementsByTagName("UL");
                        var nodeElem = nodeList[0];
                        nodeElem.style.display = '';
                        offsetHeight += Sys.UI.DomElement.getBounds(nodeElem).height;
                        nodeElem.style.display = 'none';
                    }

                    // When a child node is collapsing, calculate the proper height.
                    // So that if it is lower than get_maxGroupHeight, update the real group height
                    if(node != groupNode && !isExpanding)
                    {
                        offsetHeight = 0;
                        var divList = groupNode.get_element().getElementsByTagName("DIV");
                        // Start from 1, to skip the actual group div
                        for(i=1; i < divList.length; i++)
                        {
                            offsetHeight += Sys.UI.DomElement.getBounds(divList[i]).height;
                        }
                    }

                    // If height is greater than get_maxGroupHeight apply it.
                    if(offsetHeight > this.get_maxGroupHeight() &&
                       this.get_maxGroupHeight() + 'px' != groupElem.style.height)
                    {
                        groupElem.style.display = '';
                        groupElem.style.height = this.get_maxGroupHeight() + 'px';
                        groupElem.style.overflowY = 'auto';
                    }
                    // If height is lower than get_maxGroupHeight,
                    // and child node is collapsed, lower the total group height.
                    else if(offsetHeight < this.get_maxGroupHeight() &&
                            offsetHeight + 'px' != groupElem.style.height &&
                            node != groupNode)
                    {
                        groupElem.style.display = '';
                        groupElem.style.height = offsetHeight + 'px';
                        groupElem.style.overflowY = 'auto';
                    }
                }
            }
        }
    },

    __nKeyDown: function(dt, e)
    {
        var browserEvt = e.get_browserEvent();
        if(browserEvt &&
           (browserEvt.keyCode == Sys.UI.Key.right ||
            browserEvt.keyCode == Sys.UI.Key.left) &&
           this.get_groupExpandAction() == $IG.ExplorerBarGroupExpandAction.ButtonClick &&
           (this.get_groupExpandBehavior() != $IG.ExplorerBarGroupExpandBehavior.SingleExpanded || browserEvt.keyCode == Sys.UI.Key.right))
        {
            

            this.__bypassEventCheck = true;
        }
    },

    __nExpanding: function(dt, e)
    {
        var node = e.getNode();
        var isExpanderImageClicked = false;

        var raiseClientEvent = false;
        var nonRootNodeEvent = false;
        if (node._get_address().indexOf(".") > 0)
        {
            raiseClientEvent = true;
            nonRootNodeEvent = true;
        }

        var evt = this._lastBrowserEvent;
        if (evt != null && evt.target.id.indexOf("exp") != -1 ||
           this.__bypassEventCheck) ///When in SingleExpanded on Initial Expand. Simulate expander clicked in ButtonClick mode.
        {
            
            isExpanderImageClicked = true;
            
            if(!this.__bypassEventCheck)
                this.__hoverExpanderImage = true;

            if (this.__bypassEventCheck)
                this.__bypassEventCheck = false;
        }
        var expandMode = this.get_groupExpandAction();
		if (expandMode == $IG.ExplorerBarGroupExpandAction.ButtonClick && $util.TouchEnabled)
			expandMode = $IG.ExplorerBarGroupExpandAction.HeaderClick;
        if (
             ((expandMode == $IG.ExplorerBarGroupExpandAction.ButtonClick && !isExpanderImageClicked) && !nonRootNodeEvent)
             ||
             (expandMode == $IG.ExplorerBarGroupExpandAction.HeaderHover && node.get_expanded() && !nonRootNodeEvent)
             || (!node.get_enabled())
           )
        {
            e.set_cancel(true);
            this._lastBrowserEvent = null;
            return;
        }
        else
        {
            raiseClientEvent = true;
        }

        if (raiseClientEvent)
        {
            var args = this._raiseClientEvent('ItemExpanding', 'ExplorerBarCancel', this._lastBrowserEvent, null, new $IG.ExplorerBarItem(this, node));
            if (args && args.get_cancel())
            {
                e.set_cancel(true);
                return;
            }

            this.__handleMaxGroupHeight(e.getNode(), true);
        }

        //A.T. making sure SingleExpanded group expand behavior is handled correctly - updating images, etc.
        if (this.get_groupExpandBehavior() == $IG.ExplorerBarGroupExpandBehavior.SingleExpanded)
        {
            // Toggle the previous expanded node, only if we clicked on a root node
            // If we click on a child node the group should remain expanded.
            if (this.__currentExpandedRootNode &&
                this.__currentExpandedRootNode != node &&
                !nonRootNodeEvent)
            {
                // We are in single expanded mode and we are about to collapse
                // the old node. Since events get fired, NodeCollapsing will be fired for the old node.
                // And the event will be canceled because:
                // 1) we expect the expander image to be clicked (when in ButtonClick)
                // 2) we expect the node to not be expanded (because we are in single
                // expanded mode, and the user cannot collapse the only expanded group.)
                // so we have to bypass some of the checks.
                this.__bypassEventCheck = true;

                // K.D. Bug #29324 The expand image ExpanderNormalHover is applied when clicking fast over group headers in SingleExpanded mode
                // The animation of the previously animated node has to forced to cancel if we are clicking 
                // fast through the nodes
                var animatingNode = this.__currentExpandedRootNode.__NodeAnimation;
                if (animatingNode && animatingNode.get_isAnimating()) {
                    animatingNode.stop();
                }

                this.__currentExpandedRootNode.toggle(true);

                if(node._get_address() < this.__currentExpandedRootNode._get_address() &&
                   isExpanderImageClicked)
                {
                    // If the group being expanded has address smaller than the current expanded
                    // then if the user does not moved the mouse we should show the hover image
                    this.__hoverExpanderImage = true;
                }
                // Save the node only for group items, we do not care for children.
                // We want to preserve the child expand/collapse state.
                this.__currentExpandedRootNode = node;
            }
        }
    },

    __nHovered: function(dt, e)
    {
        var node = e.getNode();
        this._raiseClientEvent('ItemHovered', 'ExplorerBar', this._lastBrowserEvent, null, new $IG.ExplorerBarItem(this, node));
        if (node._get_address().indexOf(".") > 0) return;
        var expandMode = this.get_groupExpandAction();
        if (expandMode == $IG.ExplorerBarGroupExpandAction.HeaderHover && !node.get_expanded())
        {
            node.toggle(true);
        }
    },

    __nItemExpanded: function(dt, e)
    {
        var node = e.getNode();

        if(node.hasChildren())
        {
            this._raiseClientEvent('ItemExpanded', 'ExplorerBar', this._lastBrowserEvent, null, new $IG.ExplorerBarItem(this, node));
        }

        // If child item is expanded or collapsed return.
        if (node._get_address().indexOf(".") > 0)
            return;

        if (this.__hoverExpanderImage)
        {
            this.__handleImageHover(node);
            this.__hoverExpanderImage = false;
        }
        else
        {
            this.__handleExpandCollapse(node);
        }

        this._lastBrowserEvent = null;
    },

    __nItemCollapsed: function(dt, e)
    {
        var node = e.getNode();

        if(node.hasChildren())
        {
            this._raiseClientEvent('ItemCollapsed','ExplorerBar',this._lastBrowserEvent,null,new $IG.ExplorerBarItem(this,node));
            this.__handleMaxGroupHeight(e.getNode(),false);
        }

        // If child item is expanded collapsed return.
        if (node._get_address().indexOf(".") > 0)
            return;

        if (this.__hoverExpanderImage)
        {
            this.__handleImageHover(node);
            this.__hoverExpanderImage = false;
        }
        else
        {
            this.__handleExpandCollapse(node);
        }

        this._lastBrowserEvent = null;
    },

    

    

    get_groupExpandBehavior: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.WebExplorerBar.groupExpandBehavior">Get the group behavior mode.(SingleExpanded | AnyExpandable | AllExpanded)</summary>
        /// <value type="Infragistics.Web.UI.ExplorerBarGroupExpandBehavior"></value>
        return this._get_value($IG.WebExplorerBarProps.GroupExpandBehavior);
    },

    get_groupExpandAction: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.WebExplorerBar.groupExpandAction">Get the group exapnd action.(ButtonClick | HeaderClick | HeaderHover)</summary>
        /// <value type="Infragistics.Web.UI.ExplorerBarGroupExpandAction"></value>
        return this._get_value($IG.WebExplorerBarProps.GroupExpandAction);
    },

    get_maxGroupHeight: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.WebExplorerBar.maxGroupHeight">Get the maximum group height.</summary>
        /// <value type="int"></value>
        return this._get_value($IG.WebExplorerBarProps.MaxGroupHeight);
    },

    // K.D. June 7th, 2011 Bug #78008 Introducing a getter for the new prop
    get_singleExpandExpanded: function () {
        return this._get_value($IG.WebExplorerBarProps.SingleExpandExpanded);
    },

    getExplorerBarItems: function()
    {
        ///<summary locid="M:J#Infragistics.Web.UI.WebExplorerBar.getExplorerBarItems">Get a collection that contains the subnodes of the current group.</summary>
        /// <value type="Infragistics.Web.UI.ExplorerBarItemCollection"></value>
        if ($util.isNullOrUndefined(this._iCollection) ||
		    $util.isNullOrUndefined(this._iCollection._control)) 
            this._iCollection = new $IG.ExplorerBarItemCollection(this, this._tree.getNodes());
        return this._iCollection;
    },

    get_selectedItem: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.WebExplorerBar.selectedItem">Get the currently selected item.</summary>
        /// <value type="Infragistics.Web.UI.ExplorerBarItem"></value>
        var nodes = ig_controls[this._dtID].get_selectedNodes();
        if (nodes && nodes.length == 0) return null;
        else
            return new $IG.ExplorerBarItem(this,nodes[0]);
    },

    selectGroup: function(index, selected, toggle)
    {
        /// <summary locid="M:J#Infragistics.Web.UI.WebExplorerBar.selectGroup">
        /// Selects a group by its index.
        /// </summary>
        /// <param name="index" type="int">Index of the specified group.</param>
        /// <param name="selected" type="Boolean">Boolean value. States whether the item will be selected or deselected.</param>
        /// <param name="toggle" type="Boolean">Optional boolean value. Specifies whether to expand or collapse the group.</param>
        var items = this.getExplorerBarItems();
        var item = items.getItem(index);
        item.set_selected(selected);
        if (toggle)
        {
            item.toggle();
        }
    }

    ///
    /// <summary>
    /// returns the item (any item on any level) that matches the passed text 
    /// if no item is found, null is returned
    /// </summary>
    
























}
$IG.WebExplorerBar.registerClass('Infragistics.Web.UI.WebExplorerBar', $IG.ControlMain);

$IG.WebExplorerBar.find = function (clientID)
{
	///<summary>Finds WebExplorerBar by its client ID.</summary>
	///<param name="clientID" type="String">Client ID of the control to look for.</param>
	///<returns type="Infragistics.Web.UI.WebExplorerBar">Reference to the WebExplorerBar control object that corresponds to specified client ID.</returns>
};

$IG.WebExplorerBar.from = function (obj)
{
	///<summary>Casts passed in object to the WebExplorerBar type.</summary>
	///<param name="obj">Object to convert to the WebExplorerBar type.</param>
	///<returns type="Infragistics.Web.UI.WebExplorerBar">Reference to the same object that is passed in, only type converted to the WebExplorerBar type.</returns>
};

$IG.ExplorerBarItem = function(explorerBar, node)
{
    /// <summary locid="T:J#Infragistics.Web.UI.ExplorerBarItem">
    /// Creates WebExplorerBar Base Item.
    /// </summary>
    //$IG.WebExplorerBar.initializeBase(this, [element]);
    this._explorerBar = explorerBar;
    this._node = node;
}

$IG.ExplorerBarItem.prototype =
{
    _thisType: 'ExplorerBarItem',
    _explorerBar: $IG.WebExplorerBar,
    _node: $IG.Node,
    _itemCollection: $IG.ExplorerBarItemCollection,

    set_text: function(text)
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.text">
        /// Sets the text content of an item within the explorer bar.
        ///</summary>
        ///<param name="text" type="String">Text content</param>
        var textElem = this.get_textElement();
        if (textElem)
            textElem.innerHTML = text;
    },

    get_text: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.text">
        /// Gets the text content of an item within the explorer bar.
        ///</summary>
        ///<value type="String"></value>
        var textElem = this.get_textElement();
        if (textElem)
            return textElem.innerHTML;
    },

    get_textElement: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.textElement">Gets a reference to the Html Element that contains the text of the item.</summary>
        ///<returns domElement="true"></returns>
        var div = this._node.get_textElement();
        if (div)
        {
            var linkNode = div.firstChild; // the <a> tag, if no image
            if (div.firstChild && (div.firstChild.nodeName == "IMG" || div.firstChild.nodeName == "#text"))
            {
                linkNode = div.firstChild.nextSibling;
            }

            if (linkNode)
            {
                var spanNode = linkNode.firstChild;
                if (linkNode.firstChild && (linkNode.firstChild.nodeName == "IMG" || linkNode.firstChild.nodeName == "#text"))
                {
                    spanNode = linkNode.firstChild.nextSibling;
                }
                if (spanNode)
                    return spanNode;
            }
        }
        return null;
    },

    get_anchorElement: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.anchorElement">Get a reference to the Anchor Html Element associated with this item.</summary>
        ///<returns domElement="true"></returns>
        return this._node.get_anchorElement();
    },

    set_selected: function(value)
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.selected">
        /// Sets the item to be selected using the SelectedCssClass
        ///</summary>
        ///<param name="value" type="Boolean">Item that will be selected.</param>

        var selItem = this._explorerBar.get_selectedItem();
        if(!$util.isNullOrUndefined(selItem) && value)
            selItem.set_selected(false);

        if(value !== this.get_selected())
        {
            this._node.set_selected(value);
            // K.D. March 13th, 2012 Bug #104166 Active style persists on old items after selecting a new item from javascript.
            // Changing the active node when an API call is performed
            this._node._get_owner().set_activeNode(this._node);
        }
    },

    get_selected: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.selected">
        /// Get whether the item is selected.
        ///</summary>
        ///<value type="Boolean"></value>
        return this._node.get_selected();
    },

    set_enabled: function(value)
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.enabled">
        /// Sets an item's enabled state
        ///</summary>
        ///<param name="value" type="Boolean">Boolean value. True for enabled, false for disabled.</param>
        this._node.set_enabled(value);
    },

    get_enabled: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.enabled">
        /// Get whether the item is enabled.
        ///</summary>
        ///<value type="Boolean"></value>
        return this._node.get_enabled();
    },

    get_cssClass: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.cssClass">
        /// Get the CSS class applied to this item.
        ///</summary>
        ///<value type="String"></value>
        return this._node.get_cssClass();
    },

    get_selectedCssClass: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.selectedCssClass">
        /// Get the selected CSS class applied to this item.
        ///</summary>
        ///<value type="String"></value>
        return this._node.get_selectedCssClass();
    },

    get_activeCssClass: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.activeCssClass">
        /// Get the active CSS class applied to this item.
        ///</summary>
        ///<value type="String"></value>
        return this._node.get_activeCssClass();
    },

    get_hoverCssClass: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.hoverCssClass">
        /// Get the hover CSS class applied to this item.
        ///</summary>
        ///<value type="String"></value>
        return this._node.get_hoverCssClass();
    },

    get_disabledCssClass: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.disabledCssClass">
        /// Get the disabled CSS class applied to this item.
        ///</summary>
        ///<value type="String"></value>
        return this._node.get_disabledCssClass();
    },

    get_navigateUrl: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.navigateUrl">
        /// Get the url associated with the item. When the item is clicked, the Url will be activated.
        ///</summary>
        ///<value type="String"></value>
        return this._node.get_navigateUrl();
    },

    get_target: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.target">
        /// Get the target frame associated with the item. The target is used in conjunction with the NavigateUrl property. The target identifies the Frame or IFrame within the page that has the same corresponding Name attribute as the Target property.
        ///</summary>
        ///<value type="String"></value>
        return this._node.get_target();
    },

    get_visible: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.visible">
        /// Get whether the item is visible or not.
        ///</summary>
        ///<value type="Boolean"></value>
        return this._node.get_visible();
    },

    toggle: function(fireEvents)
    {
        ///<summary locid="M:J#Infragistics.Web.UI.ExplorerBarItem.toggle">
        /// Changes the Expanded state of the item to the opposite value from what it is currently. If the item is
        /// expanded, then it will be collapsed. If the item is collapsed, it will be expanded.
        ///</summary>
        ///<param name="fireEvents" type="Boolean">If true, client side events will be fired for the expansion or collapse.</param>
        this._node.toggle(fireEvents);
    },

    get_expanded: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.expanded">
        /// Get whether the item is expanded.
        ///</summary>
        ///<value type="Boolean"></value>
        return this._node.get_expanded();
    },

    set_expanded: function(value, fireEvents)
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.expanded">
        /// Sets the expanded state of an item to the passed in value.
        ///</summary>
        ///<param name="value" type="Boolean">If true, item will be expanded, otherwise it will be collapsed.</param>
        ///<param name="fireEvents" type="Boolean">If true, client side events will be fired for the expansion or collapse.</param>

		
		var handler = fireEvents ? null : Function.createDelegate(this, this._expandedWithoutEventsHandler);
		this._node.set_expanded(value, fireEvents, handler);
		if (this._explorerBar)
			this._explorerBar.__handleExpandCollapse(this);
    },
	
	_expandedWithoutEventsHandler: function ()
	{
		if (this._explorerBar)
			this._explorerBar.__handleExpandCollapse(this);
	},

    get_childItem: function(index)
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.childItem">
        /// Get the child item at the specified index.
        ///</summary>
        ///<param name="index" type="int">Specify an index of a child item.</param>
        ///<returns type="Infragistics.Web.UI.ExplorerBarItem" mayBeNull="true">The item at the index specified. Null if the item does not exist.</returns>
        return new $IG.ExplorerBarItem(this._explorerBar, this._node.get_childNode(index));
    },

    hasChildren: function()
    {
        ///<summary locid="M:J#Infragistics.Web.UI.ExplorerBarItem.hasChildren">
        /// Get whether the item has children.
        ///</summary>
        ///<value type="Boolean"></value>
        return this._node.hasChildren();
    },

    get_childrenCount: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.childrenCount">
        /// Get the number of children.
        ///</summary>
        ///<value type="int"></value>
        return this._node.get_childrenCount();
    },

    get_parentItem: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.parentItem">
        /// Get the parend item of this item. If this item is at the top of the item hierarchy, null is returned.
        ///</summary>
        ///<value type="Infragistics.Web.UI.ExplorerBarItem" mayBeNull="true"></value>
        return new $IG.ExplorerBarItem(this._explorerBar, this._node.get_parentNode());
    },

    get_nextItem: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.nextItem">
        /// Get the next sibling item of this item. If this is the last item in the collection, null is returned.
        ///</summary>
        ///<value type="Infragistics.Web.UI.ExplorerBarItem" mayBeNull="true"></value>
        return new $IG.ExplorerBarItem(this._explorerBar, this._node.get_nextNode());
    },

    get_previousItem: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.previousItem">
        /// Get the previous sibling item of this item. If this is the first item in the collection, null is returned.
        ///</summary>
        ///<value type="Infragistics.Web.UI.ExplorerBarItem" mayBeNull="true"></value>
        return new $IG.ExplorerBarItem(this._explorerBar, this._node.get_previousNode());
    },

    get_element: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.element">Get the DOM Element associated with this item.</summary>
        ///<returns domElement="true"></returns>
        return this._node.get_element();
    },

    get_value: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.value">
        /// Get the value of an ExplorerBarItem.
        ///</summary>
        ///<value type="String"></value>
        return this._node.get_valueString();
    },

    set_value: function(value)
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.value">
        /// Sets the value of an ExplorerBarItem.
        ///</summary>
        ///<param name="value" type="String">Value for an item.</param>
        this._node.set_valueString(value);
    },

    getItems: function()
    {
        ///<summary locid="M:J#Infragistics.Web.UI.ExplorerBarItem.getItems">
        /// Get the collection that contains children of the current item.
        ///</summary>
        ///<value type="Infragistics.Web.UI.ExplorerBarItemCollection"></value>
        if (this._itemCollection == null || typeof (this._itemCollection) == 'undefined')
            this._itemCollection = new $IG.ExplorerBarItemCollection(this._explorerBar, this._node.getItems());
        return this._itemCollection;
    },
    
    getSiblings: function()
    {
        ///<summary locid="M:J#Infragistics.Web.UI.ExplorerBarItem.getSiblings">
        /// Get the collection that contains the current item.
        ///</summary>
        ///<value type="Infragistics.Web.UI.ExplorerBarItemCollection"></value>
        var parent = this._node.get_parentNode();
        if(!$util.isNullOrUndefined(parent))
        {
            return new $IG.ExplorerBarItemCollection(this._explorerBar, parent.getItems());
        }
        else // Current node is group and it does not have parent, then return the groups collection.
        {
            return this._explorerBar.getExplorerBarItems();
        }
    }
}
$IG.ExplorerBarItem.registerClass('Infragistics.Web.UI.ExplorerBarItem');


$IG.ExplorerBarItemCollection = function(explorerBar, nodeCollection)
{
    this._explorerBar = explorerBar;
    this._nodeCollection = nodeCollection;
}

$IG.ExplorerBarItemCollection.prototype =
{
    _explorerBar: $IG.WebExplorerBar,
    _nodeCollection: $IG.NodeCollection,

    getItem: function(index)
    {
        ///<summary locid="M:J#Infragistics.Web.UI.ExplorerBarItem.getItem">
        /// Get the item or group at the specified index.
        ///</summary>
        ///<param name="index" type="int">The index of the item.</param>
        ///<returns type="Infragistics.Web.UI.ExplorerBarItem">The item at the specified index.</returns>
        return new $IG.ExplorerBarItem(this._explorerBar, this._nodeCollection.getNode(index));
    },

    get_length: function()
    {
        ///<summary locid="P:J#Infragistics.Web.UI.ExplorerBarItem.length">
        /// Get the number of items in the collection.
        ///</summary>
        ///<value type="int"></value>
        return this._nodeCollection.get_length();
    }
}
$IG.ExplorerBarItemCollection.registerClass('Infragistics.Web.UI.ExplorerBarItemCollection');

// EVENT ARGS
$IG.ExplorerBarCancelEventArgs = function()
{
    ///<summary locid="T:J#Infragistics.Web.UI.ExplorerBarCancelEventArgs">
    ///Used internally to constuct event arguments to be passed to Client Event handlers 
    ///</summary>
    $IG.ExplorerBarCancelEventArgs.initializeBase(this);
}

$IG.ExplorerBarCancelEventArgs.prototype =
{
    getExplorerBarItem: function()
    {
        ///<summary locid="M:J#Infragistics.Web.UI.ExplorerBarCancelEventArgs.getExplorerBarItem">
        /// Get the item for which the event fired.
        ///</summary>
        ///<value type="Infragistics.Web.UI.ExplorerBarItem"></value>
        return this._props[2];
    }
}
$IG.ExplorerBarCancelEventArgs.registerClass('Infragistics.Web.UI.ExplorerBarCancelEventArgs', $IG.CancelEventArgs);

$IG.ExplorerBarEventArgs = function()
{
    ///<summary locid="T:J#Infragistics.Web.UI.ExplorerBarEventArgs">
    ///Used internally to constuct event arguments to be passed to Client Event handlers 
    ///</summary>
    $IG.ExplorerBarEventArgs.initializeBase(this);
}

$IG.ExplorerBarEventArgs.prototype =
{
    getExplorerBarItem: function()
    {
        ///<summary locid="M:J#Infragistics.Web.UI.ExplorerBarEventArgs.getExplorerBarItem">
        /// Get the item for which the event fired.
        ///</summary>
        ///<value type="Infragistics.Web.UI.ExplorerBarItem"></value>
        return this._props[2];
    }
}
$IG.ExplorerBarEventArgs.registerClass('Infragistics.Web.UI.ExplorerBarEventArgs', $IG.EventArgs);

$IG.ExplorerBarItemSelectedEventArgs = function()
{
    ///<summary locid="T:J#Infragistics.Web.UI.ExplorerBarItemSelectedEventArgs">
    /// Used internally to constuct event arguments to be passed to ExplorerBar event selection handlers
    ///</summary>
    $IG.ExplorerBarItemSelectedEventArgs.initializeBase(this);
}

$IG.ExplorerBarItemSelectedEventArgs.prototype =
{
    
    getOldSelectedItem: function()
    {
        ///<summary locid="M:J#Infragistics.Web.UI.ExplorerBarItemSelectedEventArgs.getOldSelectedItem">
        /// Get the old selected item.
        ///</summary>
        ///<value type="Infragistics.Web.UI.ExplorerBarItem"></value>
        return this._props[2];
    },

    getNewSelectedItem: function()
    {
        ///<summary locid="M:J#Infragistics.Web.UI.ExplorerBarItemSelectedEventArgs.getNewSelectedItem">
        /// Get the new selected item.
        ///</summary>
        ///<value type="Infragistics.Web.UI.ExplorerBarItem"></value>
        return this._props[3];
    }
}
$IG.ExplorerBarItemSelectedEventArgs.registerClass('Infragistics.Web.UI.ExplorerBarItemSelectedEventArgs', $IG.CancelEventArgs);

function isNullOrUndefined(val)
{
    var u;
    return (u === val) || (val == null);
}
